using UnityEngine;

// [adm.in] Void Visuals v1.7 (Eye-Protection & Core-Bypass Protocol)
// Prefix: A_W (World / Environment)
// Purpose: Forces matte rendering, handles async startup, orchestrates the dynamic grid,
//          and intercepts global theme flashes to protect the Admin's eyes in dark rooms.
// Fix: Solves the startup cyan flash conflict by dynamically filtering global color sweeps.

public class A_W_VoidVisuals : MonoBehaviour
{
    private MeshRenderer _renderer;
    private Material _myMaterial;
    
    [Header("Grid Integration")]
    [Tooltip("Drag the A_GridFloorController script component here to sync the procedural grid!")]
    public A_GridFloorController gridFloor;

    [Header("Identity Profile")]
    [Tooltip("Check this ONLY on your worldFloor. It intercepts global cyan flashes and forces them to safe black on boot.")]
    public bool isFloor = false;

    [Header("Neural Pulse Settings")]
    public bool usePulse = true;
    public float pulseSpeed = 2.0f;

    [Header("Graphics Override")]
    [Range(0f, 1f)]
    [Tooltip("Forcing this to 0 prevents the default blue Unity skybox from reflecting off dark surfaces.")]
    public float surfaceSmoothness = 0.0f; 

    [Header("Infrastructure Link")]
    [Tooltip("Required for the floor bypass to read background settings. If left empty, it will auto-load.")]
    public A_S_ProjectSettings settings;

    private Color _baseColor;
    private bool _hasSyncedWithLedger = false;
    private string _colorPropertyName = "_BaseColor";

    void Awake()
    {
        _renderer = GetComponent<MeshRenderer>();
        
        // Auto-heal settings if unassigned in the inspector
        if (settings == null)
        {
            settings = Resources.Load<A_S_ProjectSettings>("A_S_GlobalSettings");
        }

        if (_renderer != null)
        {
            _myMaterial = _renderer.material;
            _myMaterial.EnableKeyword("_EMISSION");
            
            // Auto-detect URP properties to maintain absolute graphic pipeline safety
            if (_myMaterial.HasProperty("_BaseColor")) _colorPropertyName = "_BaseColor";
            else if (_myMaterial.HasProperty("_Color")) _colorPropertyName = "_Color";

            // 1. ELIMINATE SKYBOX REFLECTION: Force-kill glossiness properties
            if (_myMaterial.HasProperty("_Glossiness"))
                _myMaterial.SetFloat("_Glossiness", surfaceSmoothness);
                
            if (_myMaterial.HasProperty("_Smoothness"))
                _myMaterial.SetFloat("_Smoothness", surfaceSmoothness);

            // 2. PREVENT LATENCY FLASH: Start at pure black baseline
            _baseColor = Color.black;
            SetMaterialColor(_baseColor);
            _myMaterial.SetColor("_EmissionColor", Color.black);
        }
    }

    void Update()
    {
        // Only run the pulse once we have successfully intercepted our first network state
        // Note: We bypass the pulse on the floor to prevent background noise!
        if (usePulse && _myMaterial != null && _hasSyncedWithLedger && !isFloor)
        {
            float emission = 0.5f + Mathf.PingPong(Time.time * pulseSpeed, 1.0f);
            _myMaterial.SetColor("_EmissionColor", _baseColor * emission);
        }
    }

    /// <summary>
    /// Triggered by the network state thread. Orchestrates the physical color shifts and grid regenerations.
    /// </summary>
    public void SetTheme(Color targetColor)
    {
        _hasSyncedWithLedger = true; // Handshake complete. Safe to start the neural pulse.

        // --- THE DYNAMIC BYPASS FILTER ---
        // If this script is marked as the floor, we intercept the WorldController's global cyan/charcoal sweeps
        // and force it to default to our background settings to prevent eye-strain flashes!
        if (isFloor && settings != null)
        {
            if (targetColor == settings.darkObjectColor)
            {
                targetColor = settings.darkBackground; // Safe Black!
            }
            else if (targetColor == settings.lightObjectColor)
            {
                targetColor = settings.lightBackground; // Safe Off-White!
            }
        }

        _baseColor = targetColor;

        if (_myMaterial != null)
        {
            // --- DYNAMIC GRID COGNITIVE HANDSHAKE ---
            if (gridFloor != null)
            {
                // We hand the color over to the Grid Controller directly! 
                gridFloor.SetBaseColor(targetColor);
            }
            else
            {
                // Standard fallback if the grid controller link is unassigned in the inspector
                SetMaterialColor(targetColor);
            }

            // Update Emission to scale cleanly with the ledger color
            if (!isFloor)
            {
                _myMaterial.SetColor("_EmissionColor", targetColor * 0.7f);
            }
            else
            {
                // Ensure the floor itself has zero emission noise to keep contrast sharp
                _myMaterial.SetColor("_EmissionColor", Color.clear);
            }
        }
    }

    private void SetMaterialColor(Color color)
    {
        if (_myMaterial.HasProperty(_colorPropertyName))
            _myMaterial.SetColor(_colorPropertyName, color);
    }

    private void OnDestroy()
    {
        if (_myMaterial != null)
        {
            Destroy(_myMaterial);
        }
    }
}