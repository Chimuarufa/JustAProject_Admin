using UnityEngine;

// [adm.in] Data Rain Controller v1.0
// Prefix: A_W (World)
// Purpose: Modulates the computational ASCII rain speed based on the system's Neural Stress.
// VRAM Cost: Minimal (Hardware instanced particles).

public class A_W_DataRain : MonoBehaviour
{
    [Header("System Links")]
    public ParticleSystem asciiParticles;
    public A_UI_Terminal terminal;

    [Header("Atmosphere Settings")]
    public float calmSpeed = 1.0f;
    public float panicSpeed = 5.0f;

    void Start()
    {
        if (asciiParticles == null) asciiParticles = GetComponent<ParticleSystem>();
        if (terminal == null) terminal = FindObjectOfType<A_UI_Terminal>();
    }

    void Update()
    {
        if (asciiParticles == null || terminal == null) return;

        // Read the stress from the terminal (0 to 100)
        float stressFactor = terminal.neuralStress / 100f;

        // Dynamically shift the rain simulation speed based on how panicked the AI is
        var mainModule = asciiParticles.main;
        mainModule.simulationSpeed = Mathf.Lerp(calmSpeed, panicSpeed, stressFactor);
    }
}