using UnityEngine;
using UnityEngine.EventSystems;

// [adm.in] NPC Interaction v1.0
// Prefix: A_NPC (Entity Logic)
// Purpose: Handles the physical click to trigger the Neural Awakening.

public class A_NPC_Interaction : MonoBehaviour
{
    [Header("Identity")]
    public string npcName = "[ADM.IN]";
    
    [Header("Neural Link")]
    public A_UI_Terminal terminal;

    [Header("Visual Feedback")]
    public Color highlightColor = Color.cyan;
    private Color _originalColor;
    private MeshRenderer _renderer;

    void Awake()
    {
        if (terminal == null) terminal = FindObjectOfType<A_UI_Terminal>();
        _renderer = GetComponentInChildren<MeshRenderer>();
        if (_renderer != null) _originalColor = _renderer.material.color;
    }

    // This triggers when the user clicks the NPC (requires a Collider)
    void OnMouseDown()
    {
        if (EventSystem.current.IsPointerOverGameObject()) return; // Don't click through UI

        if (terminal != null)
        {
            Debug.Log($"<color=#00ffcc>[adm.in]:</color> Awakening signal sent to {npcName}.");
        }
    }

    // Visual "Mouse Over" for that hacker/admin feel
    void OnMouseEnter()
    {
        if (_renderer != null) _renderer.material.color = highlightColor;
    }

    void OnMouseExit()
    {
        if (_renderer != null) _renderer.material.color = _originalColor;
    }
}