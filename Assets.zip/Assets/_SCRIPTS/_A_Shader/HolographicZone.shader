Shader "ADM_IN/HolographicZone"
{
    Properties
    {
        [HDR] _GlowColor ("Glow Color", Color) = (0, 1, 0.8, 1) // Cyan default
        _FadeHeight ("Wall Height Fade", Range(0.1, 10.0)) = 3.0
        _EdgeThickness ("Floor Edge Thickness", Range(0.0, 0.2)) = 0.02
    }
    SubShader
    {
        // Set up for a transparent, additive hologram effect
        Tags { "Queue"="Transparent" "RenderType"="Transparent" "IgnoreProjector"="True" }
        LOD 100

        ZWrite Off
        Cull Off // Crucial: This renders the INSIDE of the cube as well as the outside!
        Blend SrcAlpha One // Additive blending (makes it glow naturally in dark areas)

        Pass
        {
            CGPROGRAM
            #pragma vertex vert
            #pragma fragment frag
            #include "UnityCG.cginc"

            struct appdata
            {
                float4 vertex : POSITION;
            };

            struct v2f
            {
                float4 vertex : SV_POSITION;
                float3 localPos : TEXCOORD0; // We pass the 3D local position to the fragment
            };

            float4 _GlowColor;
            float _FadeHeight;
            float _EdgeThickness;

            v2f vert (appdata v)
            {
                v2f o;
                o.vertex = UnityObjectToClipPos(v.vertex);
                o.localPos = v.vertex.xyz; // Grab the raw object-space coordinates
                return o;
            }

            fixed4 frag (v2f i) : SV_Target
            {
                // A standard Unity cube has a local Y height from -0.5 to 0.5.
                // We normalize this so the absolute bottom is 0.0 and the top is 1.0.
                float normalizedY = saturate(i.localPos.y + 0.5);

                // 1. Draw a hard glowing line exactly at the bottom edge
                float isBottomEdge = step(normalizedY, _EdgeThickness);

                // 2. Create the smooth "rising walls" fade. 
                // We invert Y so the bottom is 1 (visible) and top is 0 (invisible), then curve it.
                float wallFade = pow(1.0 - normalizedY, _FadeHeight);

                // 3. Combine the hard edge and the soft fade
                float finalIntensity = max(isBottomEdge, wallFade);

                // 4. Multiply by our HDR color to make it glow
                return _GlowColor * finalIntensity;
            }
            ENDCG
        }
    }
}