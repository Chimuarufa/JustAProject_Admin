using UnityEngine;

// [adm.in] Project Settings v1.8
// Optimized for Dolphin-Mistral 7B & The Isometric Void.
// Purpose: Updated default model and established VRAM safety buffers for 7B inference.

[CreateAssetMenu(fileName = "A_S_GlobalSettings", menuName = "[adm.in]/Settings/GeneralSettings")]
public class A_S_ProjectSettings : ScriptableObject
{
    [Header("Neural Infrastructure")]
    public string ollamaUrl = "http://127.0.0.1:11434"; 
    public string modelName = "dolphin-mistral:7b"; // Updated to Dolphin Standard
    [Range(0, 1)] public float temperature = 0.4f;   // Dolphin likes slightly higher temp for snark

    [Header("Feature Toggles")]
    public bool bypassDatabaseForNow = false;
    public string memoryUrl = "http://127.0.0.1:8000/interact";

    [Header("The Void Theme")]
    public bool isDarkMode = true;
    
    [Header("Dark Mode Colors")]
    public Color darkBackground = Color.black;
    public Color darkObjectColor = new Color(0f, 1f, 0.8f); // Cyan

    [Header("Light Mode Colors")]
    public Color lightBackground = new Color(0.9f, 0.9f, 0.9f); // Off-white
    public Color lightObjectColor = new Color(0.1f, 0.1f, 0.1f); // Charcoal
}