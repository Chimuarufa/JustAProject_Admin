using UnityEngine;
using UnityEngine.Networking;
using System.Collections;
using System;

// [adm.in] Memory Viewer v1.0
// Prefix: A_AI (Neural Logic)
// Purpose: Diagnostic tool to dump the ChromaDB inventory into the console.

public class A_AI_MemoryViewer : MonoBehaviour
{
    public string serverUrl = "http://127.0.0.1:8000/inventory";

    [ContextMenu("Dump Neural Inventory")]
    public void RequestDump()
    {
        StartCoroutine(FetchInventory());
    }

    IEnumerator FetchInventory()
    {
        Debug.Log("<color=#ffcc00>[adm.in]:</color> Requesting Librarian's Ledger...");
        
        using (UnityWebRequest req = UnityWebRequest.Get(serverUrl))
        {
            yield return req.SendWebRequest();

            if (req.result == UnityWebRequest.Result.Success)
            {
                string json = req.downloadHandler.text;
                Debug.Log($"<color=#00ffcc>[DATABASE DUMP]:</color>\n{json}");
                
                // You can expand this to parse the JSON and show it in a UI ScrollView later
            }
            else
            {
                Debug.LogError($"[adm.in]: Could not reach Librarian. {req.error}");
            }
        }
    }
}