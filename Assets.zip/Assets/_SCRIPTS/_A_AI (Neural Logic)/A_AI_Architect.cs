using UnityEngine;
using UnityEngine.Networking;
using System.Collections;
using System.Collections.Generic;

// [adm.in] Architect Logic v2.0 (Sovereign Sync Edition)
// Prefix: A_AI (Neural Logic)
// Purpose: Maps physical constants from the database ledger to the 3D void.
// Fix: Implements a static instance shield to destroy duplicates and optimizes loopback addresses.

public class A_AI_Architect : MonoBehaviour
{
    // Static instance registry to enforce single-system ownership
    public static A_AI_Architect Instance { get; private set; }

    [Header("Core Infrastructure")]
    public A_UI_Terminal terminal;
    public A_S_ProjectSettings settings;
    
    [Header("Progression Link")]
    public A_LevelManager levelManager; 

    [Header("Managed Targets")]
    public GameObject centralCube;
    public GameObject worldFloor;

    [System.Serializable]
    public class LedgerData { 
        public string cube_color; 
        public string floor_color; 
        public string cube_size;
        public string mission_id;
        public string cube_count;
        public string sphere_count;
        public string fragment_count;
        public string gravity; 
    }

    [System.Serializable]
    public class InventoryResponse { public LedgerData ledger; }

    private bool _isSyncing = false;

    void Awake()
    {
        // --- THE SOVEREIGN INSTANCE SHIELD ---
        // If an architect is already registered, destroy the duplicate immediately
        if (Instance != null && Instance != this)
        {
            Debug.LogWarning($"<color=orange>[adm.in]:</color> Duplicate A_AI_Architect found on GameObject <b>'{gameObject.name}'</b>. " +
                             $"Self-destructing component to protect the render state!");
            Destroy(this);
            return;
        }

        Instance = this;
    }

    void Start() 
    {
        // Safety lock: only let the sovereign instance initialize
        if (Instance != this) return;

        StartCoroutine(InitialSyncDelayed()); 
    }

    public void Execute(string text) 
    { 
        if (Instance == this) StartCoroutine(SyncWithLedger()); 
    }

    // Prevents race conditions during startup frame calculations
    private IEnumerator InitialSyncDelayed()
    {
        Debug.Log("<color=#39FF14>[adm.in]:</color> Initiating Cold-Boot Persistence Sync...");
        yield return new WaitForSeconds(0.1f); // Micro-buffer for rendering state initialization
        StartCoroutine(SyncWithLedger());
    }

    public IEnumerator SyncWithLedger()
    {
        if (_isSyncing || settings == null) yield break;
        _isSyncing = true;

        // --- IP RESOLUTION OPTIMIZATION ---
        // Force replace "localhost" with hardcoded "127.0.0.1" to skip Windows IPv6 loopback timeouts
        string cleanUrl = settings.memoryUrl.Replace("/interact", "/inventory");
        if (cleanUrl.Contains("localhost"))
        {
            cleanUrl = cleanUrl.Replace("localhost", "127.0.0.1");
        }

        using (UnityWebRequest req = UnityWebRequest.Get(cleanUrl))
        {
            req.timeout = 3; // 3-second fail-safe timeout
            yield return req.SendWebRequest();

            if (req.result == UnityWebRequest.Result.Success)
            {
                Debug.Log($"<color=#00FFFF>[sys]:</color> Received Ledger: {req.downloadHandler.text}");
                InventoryResponse data = JsonUtility.FromJson<InventoryResponse>(req.downloadHandler.text);
                if (data != null && data.ledger != null)
                {
                    ApplyLedgerToTargets(data.ledger);
                }
            }
            else
            {
                Debug.LogWarning($"[adm.in] Sync Failed: {req.error}");
            }
        }

        _isSyncing = false;
    }

    void ApplyLedgerToTargets(LedgerData ledger)
    {
        UpdateColor(centralCube, ledger.cube_color);

        // --- THE MULTI-FLOOR BYPASS ---
        // Auto-detect every single VoidVisuals script currently active in the Mega-Scene
        A_W_VoidVisuals[] allVisuals = FindObjectsOfType<A_W_VoidVisuals>();
        foreach (A_W_VoidVisuals vv in allVisuals)
        {
            // If it is marked as a floor, aggressively apply the ledger color to it!
            if (vv.isFloor && !string.IsNullOrEmpty(ledger.floor_color))
            {
                if (ColorUtility.TryParseHtmlString(ledger.floor_color, out Color c))
                {
                    vv.SetTheme(c);
                }
            }
        }

        if (centralCube != null && float.TryParse(ledger.cube_size, out float s))
            centralCube.transform.localScale = Vector3.one * Mathf.Clamp(s, 0.1f, 5f);

        // Notify the level director of the fresh variables
        if (levelManager != null)
        {
            int c = 0, sp = 0, f = 0;
            int.TryParse(ledger.cube_count, out c);
            int.TryParse(ledger.sphere_count, out sp);
            int.TryParse(ledger.fragment_count, out f);
            
            levelManager.OnLedgerUpdated(
                ledger.mission_id, 
                (c + sp + f), 
                ledger.floor_color, 
                ledger.cube_color, 
                ledger.cube_size,
                ledger.gravity 
            );
        }
    }

    void UpdateColor(GameObject target, string hex)
    {
        if (target == null || string.IsNullOrEmpty(hex)) return;
        if (ColorUtility.TryParseHtmlString(hex, out Color c))
        {
            A_W_VoidVisuals vv = target.GetComponent<A_W_VoidVisuals>() ?? target.AddComponent<A_W_VoidVisuals>();
            vv.SetTheme(c);
        }
    }
}