using UnityEngine;
using UnityEngine.Networking;
using System.Collections;
using System.Text;
using System;

// [adm.in] Memory Bridge v1.4 (Sentiment-Aware)
// Prefix: A_AI (Neural Logic)
// Purpose: Passes sentiment and categories to the local ChromaDB server.
// Fix: Renamed method to 'RetrieveMemories' to match Terminal v5.9 requirements.

public class A_AI_MemoryBridge : MonoBehaviour
{
    [Header("Server Configuration")]
    public string serverUrl = "http://127.0.0.1:8000";
    
    [Header("Live Metrics")]
    public int memoriesCached = 0;

    [Serializable]
    public class MemoryEntry {
        public string id;
        public string text;
        public string category;
        public int sentiment; // -1, 0, 1
    }

    [Serializable]
    public class QueryRequest {
        public string text;
        public int n_results = 3;
        public string category_filter;
    }

    [Serializable]
    public class QueryResponse {
        public string[] documents;
        public string[] ids;
    }

    // --- STORAGE (Matches Terminal v5.9) ---
    public void StoreMemory(string content, string category = "general", int sentiment = 0)
    {
        string uniqueId = "mem_" + DateTime.Now.Ticks;
        MemoryEntry entry = new MemoryEntry { 
            id = uniqueId, 
            text = content, 
            category = category,
            sentiment = sentiment
        };
        
        string json = JsonUtility.ToJson(entry);
        StartCoroutine(PostRequest("/add_memory", json));
    }

    // --- RETRIEVAL (Matches Terminal v5.9) ---
    public void RetrieveMemories(string prompt, string filter = null, Action<QueryResponse> callback = null)
    {
        QueryRequest request = new QueryRequest { 
            text = prompt, 
            category_filter = filter 
        };
        string json = JsonUtility.ToJson(request);
        StartCoroutine(PostQuery("/query_memory", json, callback));
    }

    private IEnumerator PostRequest(string endpoint, string json)
    {
        using (UnityWebRequest request = new UnityWebRequest(serverUrl + endpoint, "POST"))
        {
            byte[] bodyRaw = Encoding.UTF8.GetBytes(json);
            request.uploadHandler = new UploadHandlerRaw(bodyRaw);
            request.downloadHandler = new DownloadHandlerBuffer();
            request.SetRequestHeader("Content-Type", "application/json");

            yield return request.SendWebRequest();

            if (request.result == UnityWebRequest.Result.Success)
            {
                memoriesCached++;
                Debug.Log($"<color=#00ffcc>[adm.in]:</color> Memory Fragment Synced ({endpoint}).");
            }
            else
            {
                Debug.LogWarning($"<color=#ffcc00>[adm.in]:</color> Bridge Storage Error: {request.error}");
            }
        }
    }

    private IEnumerator PostQuery(string endpoint, string json, Action<QueryResponse> callback)
    {
        using (UnityWebRequest request = new UnityWebRequest(serverUrl + endpoint, "POST"))
        {
            byte[] bodyRaw = Encoding.UTF8.GetBytes(json);
            request.uploadHandler = new UploadHandlerRaw(bodyRaw);
            request.downloadHandler = new DownloadHandlerBuffer();
            request.SetRequestHeader("Content-Type", "application/json");

            yield return request.SendWebRequest();

            if (request.result == UnityWebRequest.Result.Success)
            {
                QueryResponse response = JsonUtility.FromJson<QueryResponse>(request.downloadHandler.text);
                callback?.Invoke(response);
            }
            else
            {
                Debug.LogWarning($"<color=#ffcc00>[adm.in]:</color> Bridge Retrieval Error: {request.error}");
            }
        }
    }
}