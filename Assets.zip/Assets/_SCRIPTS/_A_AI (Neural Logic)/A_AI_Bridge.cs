using UnityEngine;
using UnityEngine.Networking;
using System.Collections;
using System.Text;

// [adm.in] AI Bridge v2.50 (3-Strike Auto-Boot Edition)
// Prefix: A_AI (Neural Logic)
// Purpose: Detects high-parameter models, handles cold-boot VRAM loading, and safely retries.

public class A_AI_Bridge : MonoBehaviour 
{
    public A_S_ProjectSettings settings;
    [Header("Developer Options")]
    public bool offlineDevMode = false;

    [Header("Live Status")]
    public bool isConnected = false;
    public bool isSyncing = false;
    public string lastResult = "AWAITING_INIT";

    private bool _isHandshakeInProgress = false;
    private int _maxRetries = 3;

    void Start()
    {
        if (offlineDevMode)
    {
        isConnected = true;
        lastResult = "DEV_BYPASS_ACTIVE";
        Debug.LogWarning("<color=#00ffcc>[adm.in]:</color> OFFLINE DEV MODE ACTIVE. AI is asleep. Physics UI unlocked.");
        return;
    }
        if (settings == null)
        {
            Debug.LogError("<color=red>[adm.in]:</color> SETTINGS MISSING. Link A_S_GlobalSettings to Bridge.");
            return;
        }
        StartCoroutine(AutoBootSequence());
    }

    public void TriggerManualHandshake()
    {
        if (_isHandshakeInProgress)
        {
            Debug.LogWarning("<color=#ffcc00>[adm.in]:</color> Handshake already in progress. Please wait.");
            return;
        }
        StopAllCoroutines(); 
        StartCoroutine(SendPulse(true));
    }

    IEnumerator AutoBootSequence()
    {
        int currentTry = 0;

        while (currentTry < _maxRetries && !isConnected)
        {
            currentTry++;
            if (currentTry > 1) 
            {
                Debug.Log($"<color=#ffcc00>[adm.in]:</color> Cold Boot Retry ({currentTry}/{_maxRetries}) in 3 seconds...");
                yield return new WaitForSeconds(3f);
            }

            yield return StartCoroutine(SendPulse(true));
        }

        if (!isConnected)
        {
            Debug.LogError("<color=red>[adm.in]:</color> BOOT FAILED. Server unresponsive after 3 attempts. Manual restart required.");
            lastResult = "BOOT_FAILED";
        }
    }

    IEnumerator SendPulse(bool forceLog = false)
    {
        _isHandshakeInProgress = true;
        isSyncing = true;
        isConnected = false; 
        lastResult = "SYNCING...";

        // STRESS DETECTION
        if (settings.modelName.Contains("30b") || settings.modelName.Contains("14b"))
        {
            Debug.LogWarning($"<color=#ffcc00>[adm.in]:</color> HEAVY MODEL DETECTED ({settings.modelName}). Expect massive VRAM usage.");
        }

        string targetUrl = $"{settings.ollamaUrl}/api/chat";
        string json = "{\"model\": \"" + settings.modelName + "\", \"messages\": [{\"role\": \"user\", \"content\": \"ping\"}], \"stream\": false}";

        using (UnityWebRequest request = new UnityWebRequest(targetUrl, "POST"))
        {
            byte[] bodyRaw = Encoding.UTF8.GetBytes(json);
            request.uploadHandler = new UploadHandlerRaw(bodyRaw);
            request.downloadHandler = new DownloadHandlerBuffer();
            request.SetRequestHeader("Content-Type", "application/json");
            
            // 90 seconds gives the GTX 1060 enough time to swap memory from RAM to VRAM
            request.timeout = 90; 

            yield return request.SendWebRequest();

            isSyncing = false;
            _isHandshakeInProgress = false;

            if (request.result == UnityWebRequest.Result.Success)
            {
                isConnected = true;
                lastResult = "SUCCESS";
                
                if (forceLog) 
                {
                    string color = (settings.modelName.Contains("30b")) ? "orange" : "#00ffcc";
                    Debug.Log($"<color={color}>[adm.in]:</color> HANDSHAKE SUCCESSFUL -> <color=white>{settings.modelName}</color>");
                }
            }
            else
            {
                isConnected = false;
                if (request.result == UnityWebRequest.Result.ConnectionError) lastResult = "TIMEOUT";
                else if (request.result == UnityWebRequest.Result.ProtocolError) lastResult = "ERR_500";
                else lastResult = "OFFLINE";

                Debug.LogWarning($"<color=#ffcc00>[adm.in]:</color> BRIDGE OFFLINE. Model: {settings.modelName} | Error: {request.error}");
            }
        }
    }
}