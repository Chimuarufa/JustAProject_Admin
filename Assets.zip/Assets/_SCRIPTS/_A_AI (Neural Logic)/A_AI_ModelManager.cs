using UnityEngine;
using UnityEngine.Networking;
using System.Collections;
using System.Collections.Generic;
using TMPro;

// [adm.in] Model Manager v1.7 (Cold Start Guard)
// Prefix: A_AI (Neural Logic)
// Purpose: Increased safety buffers for the 1060's VRAM-to-RAM handover.

public class A_AI_ModelManager : MonoBehaviour
{
    [Header("Infrastructure")]
    public A_S_ProjectSettings settings;
    public TMP_Dropdown modelDropdown;

    [Header("Live Armory")]
    public List<string> installedModels = new List<string>();
    
    [Header("Safety Timing")]
    [Tooltip("How long to wait after a swap before pulsing the bridge.")]
    public float hotswapDelay = 3.5f; 

    private bool _isScanning = false;
    private bool _isInitializing = true; 

    void Start()
    {
        if (settings == null || modelDropdown == null)
        {
            Debug.LogWarning("<color=#ffcc00>[adm.in]:</color> ModelManager missing references.");
            return;
        }
        RefreshModelList();
    }

    public void RefreshModelList()
    {
        if (!_isScanning) StartCoroutine(FetchModelsRoutine());
    }

    IEnumerator FetchModelsRoutine()
    {
        _isScanning = true;
        string url = $"{settings.ollamaUrl}/api/tags";

        using (UnityWebRequest request = UnityWebRequest.Get(url))
        {
            yield return request.SendWebRequest();

            if (request.result == UnityWebRequest.Result.Success)
            {
                modelDropdown.onValueChanged.RemoveAllListeners();

                ParseOllamaTags(request.downloadHandler.text);
                PopulateUI();
                
                yield return null;
                _isInitializing = false;

                modelDropdown.onValueChanged.AddListener(delegate { OnDropdownChanged(); });

                Debug.Log($"<color=#00ffcc>[adm.in]:</color> Armory Refreshed. {installedModels.Count} models seated.");
            }
            else
            {
                Debug.LogError($"<color=red>[adm.in]:</color> Failed to scan armory. Error: {request.error}");
                _isInitializing = false; 
            }
        }
        _isScanning = false;
    }

    void ParseOllamaTags(string json)
    {
        installedModels.Clear();
        string searchKey = "\"name\":\"";
        int pos = 0;
        while ((pos = json.IndexOf(searchKey, pos)) != -1)
        {
            pos += searchKey.Length;
            int end = json.IndexOf("\"", pos);
            if (end != -1)
            {
                string modelName = json.Substring(pos, end - pos);
                if (!installedModels.Contains(modelName)) installedModels.Add(modelName);
                pos = end;
            }
        }
    }

    void PopulateUI()
    {
        modelDropdown.ClearOptions();
        List<TMP_Dropdown.OptionData> options = new List<TMP_Dropdown.OptionData>();
        foreach(string m in installedModels) options.Add(new TMP_Dropdown.OptionData(m));
        modelDropdown.AddOptions(options);

        int currentIdx = installedModels.FindIndex(m => m == settings.modelName);
        if (currentIdx != -1) modelDropdown.value = currentIdx;
    }

    public void OnDropdownChanged()
    {
        if (_isInitializing || installedModels.Count == 0) return;

        string selected = installedModels[modelDropdown.value];
        settings.modelName = selected;
        
        Debug.Log($"<color=#ffcc00>[adm.in]:</color> Hotswapped to -> <color=white>{selected}</color>. Initiating Cold Start Buffer...");
        StopCoroutine(nameof(DelayedHandshakePulse));
        StartCoroutine(nameof(DelayedHandshakePulse));
    }

    IEnumerator DelayedHandshakePulse()
    {
        yield return new WaitForSeconds(hotswapDelay);

        A_AI_Bridge bridge = FindObjectOfType<A_AI_Bridge>();
        if (bridge != null) 
        {
            Debug.Log($"<color=#00ffcc>[adm.in]:</color> Buffer expired. Pulsing {settings.modelName}...");
            bridge.TriggerManualHandshake();
        }
    }
}