using UnityEngine;

// [adm.in] Lazy Isometric Camera v1.1
// Prefix: A_ (Architecture)
// Purpose: Smoothly tracks the player's position WITHOUT rotating, preserving the true Isometric angle.

public class A_CameraController : MonoBehaviour
{
    [Header("Tracking Target")]
    [Tooltip("Drag your Player capsule here")]
    public Transform target;

    [Header("Camera Settings")]
    [Tooltip("How fast the camera catches up to the player. Lower = lazier.")]
    [Range(1f, 15f)] public float smoothSpeed = 5f;
    
    [Tooltip("True 45-degree diagonal offset to match the World Controller's rotation.")]
    public Vector3 offset = new Vector3(-10f, 15f, -10f);

    void Start()
    {
        // If you forget to assign the target in the inspector, it tries to find the Player automatically
        if (target == null)
        {
            GameObject playerObj = GameObject.FindGameObjectWithTag("Player");
            if (playerObj != null) target = playerObj.transform;
        }

        // On boot, instantly snap to the player so there is no weird flying animation at the start
        if (target != null)
        {
            transform.position = target.position + offset;
            
            // THE FIX: We completely removed transform.LookAt() here.
            // We now trust A_WorldController.cs to lock the rotation to exactly (35.264, 45, 0).
        }
    }

    // We use LateUpdate for cameras! 
    // Why? It ensures the camera moves AFTER the player's Rigidbody has finished moving in FixedUpdate.
    void LateUpdate()
    {
        if (target == null) return;

        // 1. Calculate where the camera SHOULD be
        Vector3 desiredPosition = target.position + offset;

        // 2. Smoothly glide from current position to the desired position
        Vector3 smoothedPosition = Vector3.Lerp(transform.position, desiredPosition, smoothSpeed * Time.deltaTime);

        // 3. Apply the movement (Position ONLY, no rotation overrides)
        transform.position = smoothedPosition;
    }
}