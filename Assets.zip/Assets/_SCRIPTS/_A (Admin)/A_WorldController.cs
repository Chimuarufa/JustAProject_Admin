using UnityEngine;

// [adm.in] World Controller v1.8 (Sovereign Synchronizer)
// Base: v1.7 + Hardened Theme Propagator
// Purpose: Forces the "Sixty Four" isometric view and handles global light/dark transitions.

public class A_WorldController : MonoBehaviour
{
    public static A_WorldController Instance;

    [Header("Core References")]
    public A_S_ProjectSettings settings;
    public Camera mainCamera;
    
    [Header("Isometric Calibration")]
    public float orthoSize = 6f;
    private Vector3 _isoRotation = new Vector3(35.264f, 45f, 0f);

    private void Awake()
    {
        if (Instance == null) Instance = this;
        else { Destroy(gameObject); return; }

        ConfigureIsometricCamera();
    }

    void Start()
    {
        // Force an initial theme sync after the scene settles
        Invoke(nameof(UpdateTheme), 0.2f);
    }

    void ConfigureIsometricCamera()
    {
        if (mainCamera == null) mainCamera = Camera.main;
        
        mainCamera.orthographic = true;
        mainCamera.orthographicSize = orthoSize;
        
        // Locked 'Sixty Four' Isometric Angle
        mainCamera.transform.rotation = Quaternion.Euler(_isoRotation);
        
        // Positioned at a distance to view the origin
        mainCamera.transform.position = new Vector3(-10, 10, -10);
        
        Debug.Log("<color=#00ffcc>[adm.in]:</color> Isometric Perspective Calibrated.");
    }

    public void UpdateTheme()
    {
        if (settings == null || mainCamera == null) return;

        bool isDark = settings.isDarkMode;
        mainCamera.backgroundColor = isDark ? settings.darkBackground : settings.lightBackground;

        // Propagate the theme to all entities in the Void
        A_W_VoidVisuals[] visuals = FindObjectsOfType<A_W_VoidVisuals>();
        foreach (var v in visuals)
        {
            // This is the call causing the error. Ensure A_W_VoidVisuals has public void SetTheme(Color c).
            v.SetTheme(isDark ? settings.darkObjectColor : settings.lightObjectColor);
        }
    }

    public void ToggleLights()
    {
        settings.isDarkMode = !settings.isDarkMode;
        UpdateTheme();
    }
}