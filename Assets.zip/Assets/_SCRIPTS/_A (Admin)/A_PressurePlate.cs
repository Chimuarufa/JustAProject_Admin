using UnityEngine;
using UnityEngine.Events;
using System.Collections.Generic;

// [adm.in] Universal Smart Trigger v1.0
// Prefix: A_ (Architecture)
// Purpose: Detects weight. Survives the !delete command via self-cleaning lists.

public class A_PressurePlate : MonoBehaviour
{
    [Header("Event Triggers (Drag Door Here!)")]
    public UnityEvent OnPlatePressed;
    public UnityEvent OnPlateReleased;

    // We track exactly WHAT is touching the plate
    private List<Collider> touchingObjects = new List<Collider>();
    private bool isPressed = false;

    // No collision blocking, just zone detection
    void OnTriggerStay(Collider other)
    {
        // Ignore other trigger zones (like the Level Exit zone)
        if (other.isTrigger) return;

        if (!touchingObjects.Contains(other))
        {
            touchingObjects.Add(other);
        }
    }

    void OnTriggerExit(Collider other)
    {
        if (touchingObjects.Contains(other))
        {
            touchingObjects.Remove(other);
        }
    }

    void Update()
    {
        // CRITICAL FIX: If the player uses '!delete all', the cube is destroyed.
        // This line scrubs the list of any deleted objects so the plate doesn't get soft-locked.
        touchingObjects.RemoveAll(item => item == null);

        bool shouldBePressed = touchingObjects.Count > 0;

        // If weight is applied, FIRE EVENT
        if (shouldBePressed && !isPressed)
        {
            isPressed = true;
            OnPlatePressed.Invoke(); // Opens the door
            
            // Visual feedback (optional: sink the button into the floor slightly)
            transform.localPosition = new Vector3(transform.localPosition.x, -0.05f, transform.localPosition.z);
        }
        // If weight is removed, FIRE EVENT
        else if (!shouldBePressed && isPressed)
        {
            isPressed = false;
            OnPlateReleased.Invoke(); // Closes the door
            
            // Visual feedback
            transform.localPosition = new Vector3(transform.localPosition.x, 0f, transform.localPosition.z);
        }
    }
}