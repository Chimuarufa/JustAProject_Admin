using UnityEngine;
using UnityEngine.Events;
using System.Collections.Generic;

// [adm.in] Universal Smart Zone v3.0 (Minimalist Edition)
// Prefix: A_ (Architecture)
// Purpose: Detects physics presence in a zone. Toggles colors instead of moving geometry.

public class A_ZoneTrigger : MonoBehaviour
{
    [Header("Visual Feedback")]
    public Renderer zoneRenderer; // The flat floor visual
    public Color inactiveColor = new Color(0.5f, 0f, 0f, 0.5f); // Dim Red
    public Color activeColor = new Color(0f, 1f, 0.8f, 0.8f);   // Bright Cyan

    [Header("Event Triggers")]
    public UnityEvent OnZoneEntered;
    public UnityEvent OnZoneExited;

    private List<Collider> touchingObjects = new List<Collider>();
    private bool isActive = false;

    void Start()
    {
        if (zoneRenderer != null)
        {
            zoneRenderer.material.color = inactiveColor;
        }
    }

    void OnTriggerStay(Collider other)
    {
        // Ignore other triggers
        if (other.isTrigger) return;

        if (!touchingObjects.Contains(other))
            touchingObjects.Add(other);
    }

    void OnTriggerExit(Collider other)
    {
        if (touchingObjects.Contains(other))
            touchingObjects.Remove(other);
    }

    void Update()
    {
        // The Anti-!delete Shield
        touchingObjects.RemoveAll(item => item == null);
        
        bool shouldBeActive = touchingObjects.Count > 0;

        if (shouldBeActive && !isActive)
        {
            isActive = true;
            OnZoneEntered.Invoke(); 
            
            if (zoneRenderer != null)
                zoneRenderer.material.color = activeColor;
        }
        else if (!shouldBeActive && isActive)
        {
            isActive = false;
            OnZoneExited.Invoke(); 
            
            if (zoneRenderer != null)
                zoneRenderer.material.color = inactiveColor;
        }
    }
}