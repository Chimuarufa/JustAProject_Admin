using UnityEngine;
using UnityEngine.SceneManagement;

// [adm.in] System Power Controller v1.0
// Prefix: A_ (Architecture / System Utility)
// Purpose: Handles clean application termination and low-level engine reboots.
// Execution: Independent utility script to preserve core async stability.

public class A_SystemPowerController : MonoBehaviour
{
    public void QuitProgram()
    {
        
        Debug.Log("<color=red>[sys]:</color> Terminating session pipeline. Goodbye, Admin.");
        
        #if UNITY_EDITOR
            UnityEditor.EditorApplication.isPlaying = false;
        #else
            Application.Quit();
        #endif
    }
    public void RestartProgram()
    {
        Debug.Log("<color=#ffcc00>[sys]:</color> Initiating system hard reboot. Recalibrating logic gates...");
        
        Scene activeScene = SceneManager.GetActiveScene();
        SceneManager.LoadScene(activeScene.name);
    }
}