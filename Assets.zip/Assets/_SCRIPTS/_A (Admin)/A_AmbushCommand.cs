using UnityEngine;

// [adm.in] Boundary Ambush Zone v1.0

public class AmbushZone : MonoBehaviour
{
    [Header("System Link")]
    public A_UI_CommandCenter commandCenter;

    [Header("The Ambush Sequence")]
    [Tooltip("Commands to fire in order. Example: '!update floor_color red', '!spawn fragment 50', 'purge_progress'")]
    public string[] ambushCommands;

    private bool _hasTriggered = false;

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player") && !_hasTriggered)
        {
            _hasTriggered = true;
            Debug.LogWarning("<color=red>[sys]: BOUNDARY VIOLATION DETECTED. REVERTING.</color>");

            if (commandCenter != null && ambushCommands != null)
            {
                foreach (string cmd in ambushCommands)
                {
                    commandCenter.Execute(cmd);
                }
            }
            else
            {
                Debug.LogError("[sys]: Ambush failed. Command Center is not linked in the Inspector!");
            }
            
            _hasTriggered = false;
        }
    }
}