using UnityEngine;

// [adm.in] Level Exit Teleporter v2.1 (Ambush Edition)
// Prefix: A_ (Architecture)

public class A_LevelExit : MonoBehaviour
{
    [Header("Next Level Physical Coordinates")]
    public Transform nextLevelSpawnPoint;
    public Transform nextLevelAnchorZone; 

    [Header("System References")]
    public Transform spawnAnchor; 
    public A_UI_CommandCenter commandCenter;
    public A_LevelManager levelManager; 

    [Header("Narrative Settings")]
    public string nextLevelId = "level_2"; 
    public string systemMessage = "Simulation complete. Proceeding to the next level.";
    public string aiPrompt = "[SYSTEM_EVENT] User cleared Level 1. State shifted to level_2. Transition your persona and speak now.";

    [Header("Ambush Commands")]
    [Tooltip("Spams the Command Center with these exactly after teleporting. (e.g. '!spawn cube 50')")]
    public string[] commandsOnEntry;

    private bool hasTriggered = false;

    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player") && !hasTriggered)
        {
            hasTriggered = true;
            A_AudioManager.Instance.PlayLevelComplete();

            // 1. PHYSICAL: Purge old geometry
            if (commandCenter != null) commandCenter.Execute("!delete all");

            // 2. PHYSICAL: Move the Player safely
            Rigidbody rb = other.GetComponent<Rigidbody>();
            if (rb != null)
            {
                rb.interpolation = RigidbodyInterpolation.None;
                rb.position = nextLevelSpawnPoint.position;
                rb.interpolation = RigidbodyInterpolation.Interpolate;
            }

            // 3. PHYSICAL: Move the Spawn Anchor
            if (spawnAnchor != null && nextLevelAnchorZone != null)
            {
                spawnAnchor.position = nextLevelAnchorZone.position;
            }

            // 4. THE AMBUSH: Spam the Command Center!
            if (levelManager != null && levelManager.terminal != null && commandsOnEntry != null)
            {
                foreach (string cmd in commandsOnEntry)
                {
                    // Route it through SubmitChat so the UI updates and the AI knows it's a command!
                    levelManager.terminal.SubmitChat(cmd);
                }
            }

            // 5. DATABASE & AI: Update state
            if (levelManager != null)
            {
                levelManager.AdvanceLevel(nextLevelId, systemMessage);
                
                if (levelManager.terminal != null && !string.IsNullOrEmpty(aiPrompt))
                {
                    levelManager.terminal.StartCoroutine(levelManager.terminal.PostToAI(aiPrompt, levelManager.terminal.architectHex));
                }
            }

            Debug.Log($"<color=#00ffcc>[adm.in]:</color> SECTOR CLEARED. Transitioning to {nextLevelId}.");
            hasTriggered = false; 
        }
    }
}