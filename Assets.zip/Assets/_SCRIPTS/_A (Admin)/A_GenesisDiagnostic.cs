using UnityEngine;

// [adm.in] System Diagnostic Script v1.2
// Use this to verify VS Code IntelliSense and Semantic Highlighting.

public class A_GenesisDiagnostic : MonoBehaviour
{
    [Header("Sleeper Handshake Status")]
    public bool isKingSeated = false;
    
    [Tooltip("Drag A_S_GlobalSettings here from your project folder.")]
    public A_S_ProjectSettings settings;

    // TEST 1: Semantic Highlighting
    // 'A_GenesisDiagnostic' (Class) should be GOLD (#ffcc00)
    // 'Vector3' (Struct) should be CYAN (#00ffcc)
    private Vector3 _initialPosition;

    void Start()
    {
        _initialPosition = transform.position;
        VerifyHandshake();
    }

    void VerifyHandshake()
    {
        if (settings == null)
        {
            Debug.LogError("<color=#ff4444>[adm.in]:</color> SETTINGS MISSING. Right-click folder -> Create -> [adm.in] -> Settings -> GeneralSettings.");
            return;
        }

        // TEST 2: IntelliSense
        // Suggestions should appear when typing 'transform.'
        Debug.Log($"<color=#00ffcc>[adm.in]:</color> Genesis Diagnostic Initialized at {_initialPosition}");
        Debug.Log($"<color=#ffcc00>[adm.in]:</color> Target Model: {settings.modelName}");
        
        isKingSeated = true;
    }
}