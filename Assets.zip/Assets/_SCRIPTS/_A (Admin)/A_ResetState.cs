using UnityEngine;
using System.Collections.Generic;

public class A_ResetState : MonoBehaviour
{
    private static List<A_ResetState> _allResettables = new List<A_ResetState>();
    
    private Vector3 _startPos;
    private Quaternion _startRot;

    void Awake() 
    {
        _startPos = transform.position;
        _startRot = transform.rotation;
        _allResettables.Add(this);
    }

    void OnDestroy() 
    {
        _allResettables.Remove(this);
    }

    public static void ResetAll() 
    {
        // We iterate through the list properly
        foreach (A_ResetState item in _allResettables) 
        {
            if (item == null) continue;
            
            item.transform.position = item._startPos;
            item.transform.rotation = item._startRot;
            item.gameObject.SetActive(true);
            
            Rigidbody rb = item.GetComponent<Rigidbody>();
            if (rb != null) 
            {
                rb.velocity = Vector3.zero;
                rb.angularVelocity = Vector3.zero;
            }
        }
    }
}