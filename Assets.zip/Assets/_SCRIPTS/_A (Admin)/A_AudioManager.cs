using UnityEngine;

// [adm.in] Unified Audio Manager v1.0
// Prefix: A_ (Architecture / Singleton)
// Purpose: Centralized routing for all UI, BGM, and Event audio. Prevents audio clipping and simplifies memory.

public class A_AudioManager : MonoBehaviour
{
    // The Sovereign Instance Shield
    public static A_AudioManager Instance { get; private set; }

    [Header("Audio Channels")]
    [Tooltip("Plays looping background ambiance.")]
    public AudioSource bgmSource;
    [Tooltip("Plays one-off sound effects.")]
    public AudioSource sfxSource;

    [Header("The Asset Library")]
    public AudioClip bgmDrone;
    public AudioClip uiClick;
    public AudioClip keystroke;
    public AudioClip commandSuccess;
    public AudioClip commandFail;
    public AudioClip levelComplete;

    [Header("Typing Settings")]
    [Tooltip("Randomize pitch slightly so typing doesn't sound like a machine gun.")]
    [Range(0.8f, 1.2f)] public float minTypePitch = 0.95f;
    [Range(0.8f, 1.2f)] public float maxTypePitch = 1.05f;

    void Awake()
    {
        // Singleton lockdown
        if (Instance != null && Instance != this)
        {
            Destroy(this.gameObject);
            return;
        }
        Instance = this;
        DontDestroyOnLoad(this.gameObject);

        // Auto-generate AudioSources if you forgot to add them in the Inspector
        if (bgmSource == null) bgmSource = gameObject.AddComponent<AudioSource>();
        if (sfxSource == null) sfxSource = gameObject.AddComponent<AudioSource>();

        // Configure the BGM Source
        bgmSource.loop = true;
        bgmSource.volume = 0.3f; // Keep BGM subtle!
        bgmSource.spatialBlend = 0f; // 2D Sound

        // Configure the SFX Source
        sfxSource.loop = false;
        sfxSource.volume = 0.8f;
        sfxSource.spatialBlend = 0f;
    }

    void Start()
    {
        if (bgmDrone != null)
        {
            bgmSource.clip = bgmDrone;
            bgmSource.Play();
        }
    }

    // --- PUBLIC AUDIO ROUTERS ---

    public void PlayUIClick()
    {
        if (uiClick != null) sfxSource.PlayOneShot(uiClick);
    }

    public void PlayKeystroke()
    {
        if (keystroke != null)
        {
            // The trick to making typing sound premium: randomize the pitch every single keystroke.
            sfxSource.pitch = Random.Range(minTypePitch, maxTypePitch);
            
            // PlayOneShot allows multiple keys to overlap cleanly without cutting each other off
            sfxSource.PlayOneShot(keystroke, 0.4f); 
            
            // Reset pitch back to normal for other sounds
            sfxSource.pitch = 1f; 
        }
    }

    public void PlaySuccess()
    {
        if (commandSuccess != null) sfxSource.PlayOneShot(commandSuccess);
    }

    public void PlayFail()
    {
        if (commandFail != null) sfxSource.PlayOneShot(commandFail);
    }

    public void PlayLevelComplete()
    {
        if (levelComplete != null) sfxSource.PlayOneShot(levelComplete);
    }
}