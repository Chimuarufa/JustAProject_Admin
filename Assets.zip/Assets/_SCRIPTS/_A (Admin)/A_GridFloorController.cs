using UnityEngine;

// [adm.in] Dynamic Cyber Grid v2.5 (High-Contrast Color Bypass Edition)
// Prefix: A_ (Core Architecture Environment / Graphic Utility)
// Purpose: Bypasses Unity shader multiplication limits by drawing background colors directly onto the texture map.
// Debugging: Added deep console telemetry to trace state updates at runtime.

[RequireComponent(typeof(MeshRenderer))]
public class A_GridFloorController : MonoBehaviour
{
    [Header("Resolution & Performance")]
    public int textureResolution = 256;
    
    [Header("Stylization & Glow")]
    [Range(2, 16)] public int gridLineThickness = 4;
    [Range(4, 32)] public int glowRadius = 16;
    
    [Header("Tiling Setup")]
    public Vector2 tilingFactor = new Vector2(30f, 30f);

    private Texture2D _gridTexture;
    private Material _floorMaterial;
    private string _colorPropertyName = "_BaseColor"; 

    void Awake()
    {
        MeshRenderer renderer = GetComponent<MeshRenderer>();
        if (renderer != null)
        {
            _floorMaterial = renderer.material;
            
            if (_floorMaterial.HasProperty("_BaseColor")) _colorPropertyName = "_BaseColor";
            else if (_floorMaterial.HasProperty("_Color")) _colorPropertyName = "_Color";
            
            Debug.Log($"<color=#00ffcc>[grid-sys]:</color> Target shader property identified as: {_colorPropertyName}");
        }
        else
        {
            Debug.LogError("<color=red>[grid-sys]:</color> Missing MeshRenderer component on floor object!");
        }
    }

    /// <summary>
    /// Reactively updates the texture background and grid line colors based on ledger requests.
    /// </summary>
    public void SetBaseColor(Color newColor)
    {
        Debug.Log($"<color=#00ffcc>[grid-sys]:</color> SetBaseColor invoked. Target Background Color: {newColor}");

        if (_floorMaterial == null)
        {
            MeshRenderer renderer = GetComponent<MeshRenderer>();
            if (renderer != null) _floorMaterial = renderer.material;
            else return;
        }

        // --- THE GRAPHICS BYPASS TRICK ---
        // We force the material's global color property to solid white. 
        // This stops the shader's multiplier from darkening our custom neon pixels!
        if (_floorMaterial.HasProperty(_colorPropertyName))
        {
            _floorMaterial.SetColor(_colorPropertyName, Color.white);
        }

        // Generate the texture, writing 'newColor' directly to the background pixel channels
        GenerateDynamicGrid(newColor);
    }

    private void GenerateDynamicGrid(Color backgroundColor)
    {
        if (_gridTexture != null) Destroy(_gridTexture);

        _gridTexture = new Texture2D(textureResolution, textureResolution, TextureFormat.RGBA32, true);
        _gridTexture.filterMode = FilterMode.Bilinear;
        _gridTexture.wrapMode = TextureWrapMode.Repeat;

        // Calculate perceived brightness of the requested background color
        float luminance = 0.2126f * backgroundColor.r + 0.7152f * backgroundColor.g + 0.0722f * backgroundColor.b;
        
        Color gridColor;
        Color baseCellColor;

        Debug.Log($"<color=#00ffcc>[grid-sys]:</color> Background Luminance: {luminance:F4}");

        if (luminance < 0.25f)
        {
            // --- DARK MODE: Glowing Cyan Grid on a custom dark pixel background ---
            gridColor = new Color(0.0f, 1.0f, 0.9f, 1.0f); // Neon Cyan
            baseCellColor = backgroundColor;               // Painted directly onto the texture
            Debug.Log("<color=#00e5ff>[grid-sys]: Rendering Retrowave Neon mode (Dark background detected).</color>");
        }
        else
        {
            // --- LIGHT MODE: Dark Carbon lines on a custom light pixel background ---
            gridColor = new Color(0.12f, 0.12f, 0.12f, 0.85f); // Deep Carbon Gray
            baseCellColor = backgroundColor;                  // Painted directly onto the texture
            Debug.Log("<color=#808080>[grid-sys]: Rendering High-Contrast Carbon mode (Light background detected).</color>");
        }

        // Generate the texture pixels
        for (int y = 0; y < textureResolution; y++)
        {
            for (int x = 0; x < textureResolution; x++)
            {
                int distToEdgeX = Mathf.Min(x, textureResolution - x);
                int distToEdgeY = Mathf.Min(y, textureResolution - y);
                int shortestDistance = Mathf.Min(distToEdgeX, distToEdgeY);

                if (shortestDistance < gridLineThickness)
                {
                    // Sharp Core Line
                    _gridTexture.SetPixel(x, y, gridColor);
                }
                else if (shortestDistance < glowRadius && luminance < 0.25f)
                {
                    // Smooth-step glow falloff (Dark mode only)
                    float t = 1.0f - ((float)(shortestDistance - gridLineThickness) / (glowRadius - gridLineThickness));
                    t = t * t * (3f - 2f * t);

                    Color glowingColor = Color.Lerp(baseCellColor, gridColor, t * 0.6f); // Richer glow factor
                    _gridTexture.SetPixel(x, y, glowingColor);
                }
                else
                {
                    // Flat background cell color
                    _gridTexture.SetPixel(x, y, baseCellColor);
                }
            }
        }

        _gridTexture.Apply();

        // Bind texture to shader
        string texName = _floorMaterial.HasProperty("_BaseMap") ? "_BaseMap" : "_MainTex";
        _gridTexture.wrapMode = TextureWrapMode.Repeat;
        _floorMaterial.SetTexture(texName, _gridTexture);
        _floorMaterial.SetTextureScale(texName, tilingFactor);

        // Adjust emission parameter for real glow
        if (_floorMaterial.HasProperty("_EmissionColor"))
        {
            if (luminance < 0.25f)
            {
                _floorMaterial.SetColor("_EmissionColor", gridColor * 0.45f); // Crisp bloom intensity
                _floorMaterial.EnableKeyword("_EMISSION");
            }
            else
            {
                _floorMaterial.SetColor("_EmissionColor", Color.clear);
                _floorMaterial.DisableKeyword("_EMISSION");
            }
        }
        
        Debug.Log("<color=#00ffcc>[grid-sys]:</color> Procedural grid successfully updated and bound to GPU.");
    }

    private void OnDestroy()
    {
        if (_gridTexture != null) Destroy(_gridTexture);
    }
}