using UnityEngine;

// [adm.in] Player Physics Rig v3.1 (Kinetic Polish Edition)
// Prefix: A_ (Architecture)
// Purpose: Smoothed input vectors, anti-phasing physics, and dynamic particle emission.

[RequireComponent(typeof(Rigidbody))]
public class A_PlayerController : MonoBehaviour
{
    [Header("Movement Specs")]
    public float moveSpeed = 6f;
    public float rotationSpeed = 15f;
    [Range(1f, 20f)] public float moveSmoothness = 10f;
    
    [Header("State")]
    public bool IsInputLocked = false;

    [Header("Visual Polish")]
    [Tooltip("Drag a trailing particle system here. The script will toggle its emission automatically.")]
    public ParticleSystem movementParticles;
    
    private Rigidbody rb;
    private Vector3 targetInput;
    private Vector3 currentInput; 

    void Start()
    {
        rb = GetComponent<Rigidbody>();
        rb.constraints = RigidbodyConstraints.FreezeRotationX | RigidbodyConstraints.FreezeRotationY | RigidbodyConstraints.FreezeRotationZ;
        
        // Ensure particles aren't spilling out when the scene boots
        if (movementParticles != null)
        {
            var emission = movementParticles.emission;
            emission.enabled = false;
        }
    }

    void Update()
    {
        if (IsInputLocked) 
        {
            targetInput = Vector3.zero;
        }
        else
        {
            float h = Input.GetAxisRaw("Horizontal");
            float v = Input.GetAxisRaw("Vertical");

            Vector3 rawInput = new Vector3(h, 0, v).normalized;
            targetInput = Quaternion.Euler(0, 45f, 0) * rawInput;
        }

        currentInput = Vector3.Lerp(currentInput, targetInput, Time.deltaTime * moveSmoothness);
    }

    void FixedUpdate()
    {
        // Cache our movement state
        bool isMoving = currentInput.magnitude > 0.05f;

        if (isMoving)
        {
            // 1. TRUE PHYSICS MOVEMENT
            Vector3 targetVelocity = currentInput * moveSpeed;
            rb.velocity = new Vector3(targetVelocity.x, rb.velocity.y, targetVelocity.z);

            // 2. Rotate smoothly
            Quaternion targetRotation = Quaternion.LookRotation(currentInput);
            rb.MoveRotation(Quaternion.Slerp(rb.rotation, targetRotation, rotationSpeed * Time.fixedDeltaTime));
        }
        else
        {
            // 3. BRAKES
            rb.velocity = new Vector3(0, rb.velocity.y, 0);
        }

        // 4. KINETIC PARTICLES
        // Dynamically toggle the emission module based on whether the Rigidbody is actively pushing velocity
        if (movementParticles != null)
        {
            var emission = movementParticles.emission;
            emission.enabled = isMoving;
        }
    }
}