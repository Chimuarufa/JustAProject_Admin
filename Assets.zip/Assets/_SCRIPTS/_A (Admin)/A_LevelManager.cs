using UnityEngine;
using System.Collections;
using UnityEngine.Networking;

public class A_LevelManager : MonoBehaviour
{
    [Header("System Links")]
    public A_UI_Terminal terminal;
    public A_S_ProjectSettings settings;
    public A_UI_CommandCenter commandCenter;

    [Header("UI Links")]
    public A_UI_Dashboard dashboard; 

    // THE FIX: Unified variables
    public string currentMissionId = "level_1"; 
    
    [Header("Level 3 Specifics")]
    public GameObject hiddenDoorL3;

    [Header("Level 5 Specifics")]
    public GameObject hiddenDoorL5;

    [Header("Boss Spawning")]
    public GameObject bossPrefab; 
    public Transform bossSpawnPoint;
    public Transform playerTransform;
    public Transform playerSpawnPoint; 

    public void ReincarnateBoss()
    {
        // 1. Cleanup current boss if he exists
        GameObject existingBoss = GameObject.FindGameObjectWithTag("Boss");
        if (existingBoss != null) Destroy(existingBoss);

        // 2. Spawn fresh
        if (bossPrefab != null && bossSpawnPoint != null)
        {
            Instantiate(bossPrefab, bossSpawnPoint.position, bossSpawnPoint.rotation);
        }
    }

    public void OnLedgerUpdated(string missionId, int totalSpawns, string floorColor, string cubeColor, string cubeSize, string gravity)
    {
        if (!string.IsNullOrEmpty(missionId))
        {
            currentMissionId = missionId;
        }
        RefreshDashboardUI();
    }

    public void AdvanceLevel(string nextLevelId, string sysMessage)
    {
        currentMissionId = nextLevelId;
        terminal.WriteToHistory($"\n<color=#FFB200>[VOID]: {sysMessage}</color>");
        RefreshDashboardUI(); 
        StartCoroutine(PostMissionUpdate(nextLevelId));
    }

public void ResetProgressionState()
{
    // 1. Reset Mission
    currentMissionId = "level_1";
    
    // 2. Close Doors (using the names you already have)
    if (hiddenDoorL3 != null) hiddenDoorL3.SetActive(false);
    if (hiddenDoorL5 != null) hiddenDoorL5.SetActive(false);
    
    // 3. Teleport Player (using your existing variables)
    if (playerTransform != null && playerSpawnPoint != null)
    {
        var controller = playerTransform.GetComponent<CharacterController>();
        if (controller != null) controller.enabled = false;
        playerTransform.position = playerSpawnPoint.position;
        playerTransform.rotation = playerSpawnPoint.rotation;
        if (controller != null) controller.enabled = true;
    }

    // 4. Reset Boss (Using your original logic)
    GameObject oldBoss = GameObject.FindGameObjectWithTag("Boss");
    if (oldBoss != null) Destroy(oldBoss);
    if (bossPrefab != null && bossSpawnPoint != null)
    {
        Instantiate(bossPrefab, bossSpawnPoint.position, bossSpawnPoint.rotation);
    }

    // 5. Keep your existing Refresh/UI logic
    RefreshDashboardUI();
    StartCoroutine(PostMissionUpdate("level_1"));
}

  

    private void RefreshDashboardUI()
    {
        if (dashboard == null) return;

        switch (currentMissionId)
        {
            case "level_1":
                dashboard.RefreshInterface(
                    "level_1",
                    "Test 1: Manifest",
                    "WASD or Arrow Keys to move.\n" +
                    "Your job is to open the door. Use the available resources around you\n" +
                    "You can hack reality. Read the guide for more details\n" +
                    "Push any item on the pressure plate to bypass the security node.",
                    "<b>RELEVANT COMMANDS:</b>\n" +
                    "• !spawn [prefab] [qty]\n" +
                    "• <color=#39FF14>E.g. !spawn cube 1</color> \n\n" +
                    "<b>VARIABLES FOUND:</b>\n" +
                    "cube | sphere | fragment\n\n" +
                    "[Hack Tip]: Try different combinations of objects and quantities. Sometimes the solution is not as straightforward as it seems."
                );
                break;

            case "level_2":
                dashboard.RefreshInterface(
                    "level_2",
                    "Test 2: Vanish",
                    "Too much mass. The security node has been crushed under the weight of previous iterations.\n" +
                    "You cannot spawn your way out of this. You must clean the mess.",
                    "<b>DISCOVERED COMMANDS:</b>\n" +
                    "• !spawn [prefab] [qty]\n" +
                    "<b>RELEVANT COMMANDS:</b>\n" +
                    "• !delete [prefab]\n" +
                    "• <color=#FF0000>!delete all</color> \n\n" +
                    "<b>VARIABLES FOUND:</b>\n" +
                    "cube | sphere | fragment\n\n" +
                    "[Hack Tip]: Deleting specific objects may yield different results. Observe the environment's response."
                );
                break;

            case "level_3":
                dashboard.RefreshInterface(
                    "level_3",
                    "Test 3: Perception",
                    "The exit door can only be manifested if you have a key or a code\n" +
                    "Alter the environment variables to expose the hidden data, then submit the code.",
                    "<b>DISCOVERED COMMANDS:</b>\n" +
                    "• !spawn [prefab] [qty]\n" +
                    "• !delete [prefab]\n" +
                    "<b>RELEVANT COMMANDS:</b>\n" +
                    "• !update floor_color <color=#FF0000>[hex/keyword]</color>\n" +
                    "• <color=#39FF14>E.g. !update floor_color white</color> \n\n" +
                    "<b>VARIABLES FOUND:</b>\n" +
                    "floor_color | cube | sphere | fragment\n\n" +
                    "[Hack Tip]: The environment may react to certain keywords or color changes. Pay attention to the feedback you get from the system."
                );
                break;

            case "level_4":
                dashboard.RefreshInterface(
                    "level_4",
                    "Test 4: Physics",
                    "Meet CUBIE. He is flagged as [IMMORTAL]. He cannot be deleted. He is too heavy to push.\n" +
                    "If you cannot remove the object, you must remove the laws of physics binding it.",
                    "<b>DISCOVERED COMMANDS:</b>\n" +
                    "• !spawn [prefab] [qty]\n" +
                    "• !delete [prefab]\n" +
                    "• !update floor_color [hex/keyword]\n" +
                    "<b>RELEVANT COMMANDS:</b>\n" +
                    "• !update gravity <color=#FF0000>[float]</color>\n" +
                    "• <color=#39FF14>E.g. !update gravity 0</color> \n\n" +
                    "<b>VARIABLES FOUND:</b>\n" +
                    "gravity | floor_color | cube | sphere | fragment\n\n" +
                    "[Hack Tip]: Gravity is a fundamental force. Altering it may have unexpected consequences on the environment and objects within it. Experiment with different values to see how it affects Cubie and the surroundings."
                );
                break;

            case "level_5":
                dashboard.RefreshInterface(
                    "level_5",
                    "Test 5: Hacker",
                    "An Entity has block your way and hide the exit\n" +
                    "Standard commands are not effective. It is time to use all and see which one hits.\n",
                    "<b>DISCOVERED COMMANDS:</b>\n" +
                    "• !spawn [prefab] [qty]\n" +
                    "• !delete [prefab]\n" +
                    "• !update floor_color [hex/keyword]\n" +
                    "• !update gravity [float]\n" +
                    "<b>RELEVANT COMMANDS:</b>\n" +
                    "• <color=#FF0000>!delete [target]</color>\n\n" +
                    "<b>VARIABLES FOUND:</b>\n" +
                    "boss | gravity | floor_color | cube | sphere | fragment\n\n" +
                    "[Hack Tip]: The boss is a unique entity. It may have specific weaknesses or interactions."
                );
                break;

            case "victory":
                dashboard.RefreshInterface(
                    "victory",
                    "TESTS COMPLETED",
                    "You have proven your worth.\n" +
                    "Execute '/purge_progress' to terminate the simulation. Or just...walk through the door...",
                    "<b>SYSTEM STATUS:</b>\n" +
                    "• All tests completed. No further commands necessary. Enjoy your stay to explore or leave at your leisure."
                );
                break;
        }
    }

    private IEnumerator PostMissionUpdate(string nextLevelId)
    {
        if (settings == null) yield break;

        string baseUrl = settings.memoryUrl.Replace("/interact", "/update_state");
        string jsonPayload = $"{{\"key\":\"mission_id\",\"value\":\"{nextLevelId}\"}}";
        
        using (UnityWebRequest request = new UnityWebRequest(baseUrl, "POST"))
        {
            byte[] bodyRaw = System.Text.Encoding.UTF8.GetBytes(jsonPayload);
            request.uploadHandler = new UploadHandlerRaw(bodyRaw);
            request.downloadHandler = new DownloadHandlerBuffer();
            request.SetRequestHeader("Content-Type", "application/json");

            yield return request.SendWebRequest();

            if (request.result != UnityWebRequest.Result.Success)
            {
                Debug.LogError($"[adm.in] Director State Push Failed: {request.error}");
            }
            else
            {
                Debug.Log($"[adm.in] Director State Sync Success: mission_id -> {nextLevelId}");
            }
        }
    }
    
    public void MaterializeFinalExit()
    {
        if (hiddenDoorL5 != null)
        {
            hiddenDoorL5.SetActive(true);
            terminal.WriteToHistory("\n<color=#00FFCC>[SYSTEM]: Boss neutralized. Final path materialized.</color>");
        }
    }
}