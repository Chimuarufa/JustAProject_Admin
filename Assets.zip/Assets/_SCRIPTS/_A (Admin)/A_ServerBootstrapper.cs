using UnityEngine;
using System.Diagnostics;
using System.IO;

// [adm.in] Server Bootstrapper v1.0
// Prefix: A_ (Architecture)
// Purpose: Automatically launches the local Python Memory Server .bat file when the game starts.
// Pathing: Uses relative paths so it survives being moved to a USB drive or different PC.

public class A_ServerBootstrapper : MonoBehaviour
{
    [Header("Boot Configuration")]
    [Tooltip("The exact name of your batch file. It must be placed next to your .exe in the build folder!")]
    public string batchFileName = "MemoryDatabaseStart.bat";
    
    [Tooltip("Should the CMD window be visible? (Highly recommended for the hacker aesthetic).")]
    public bool showTerminalWindow = true;

    void Awake()
    {
        LaunchLocalServer();
    }

    private void LaunchLocalServer()
    {
        string batPath = "";

        #if UNITY_EDITOR
            batPath = Path.Combine(Directory.GetParent(Application.dataPath).FullName, batchFileName);
        #else
            batPath = Path.Combine(Directory.GetParent(Application.dataPath).FullName, batchFileName);
        #endif

        if (!File.Exists(batPath))
        {
            UnityEngine.Debug.LogError($"<color=red>[sys]:</color> FATAL. Bootstrapper could not find {batchFileName} at path: {batPath}");
            return;
        }

        ProcessStartInfo processInfo = new ProcessStartInfo();
        processInfo.FileName = batPath;
        
        processInfo.WorkingDirectory = Path.GetDirectoryName(batPath);
        
        processInfo.UseShellExecute = true; 
        processInfo.CreateNoWindow = !showTerminalWindow;
        
        if (showTerminalWindow)
        {
            processInfo.WindowStyle = ProcessWindowStyle.Normal;
        }
        else
        {
            processInfo.WindowStyle = ProcessWindowStyle.Hidden;
        }

        try
        {
            Process.Start(processInfo);
            UnityEngine.Debug.Log($"<color=#00ffcc>[sys]:</color> Successfully launched local server payload: {batchFileName}");
        }
        catch (System.Exception e)
        {
            UnityEngine.Debug.LogError($"<color=red>[sys]:</color> Failed to launch server payload. Error: {e.Message}");
        }
    }
}