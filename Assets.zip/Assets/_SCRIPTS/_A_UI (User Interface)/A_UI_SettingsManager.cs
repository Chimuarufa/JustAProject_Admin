using UnityEngine;
using UnityEngine.UI;

// [adm.in] Settings Manager v1.0
// Prefix: A_UI (User Interface)
// Purpose: Toggles the System Override Panel and routes UI events (Glitch/Snapshot).
// Note: This connects the Terminal UI and Resource Monitor to physical buttons.

public class A_UI_SettingsManager : MonoBehaviour
{
    [Header("Panel Bindings")]
    public GameObject settingsPanel;
    public KeyCode toggleKey = KeyCode.Escape; 

    [Header("Module Links")]
    public A_UI_ResourceMonitor monitor;

    private bool _isOpen = false;

    void Start()
    {
        // Ensure the panel starts hidden
        if (settingsPanel != null) settingsPanel.SetActive(false);
    }

    void Update()
    {
        // Toggle Settings with Escape 
        if (Input.GetKeyDown(toggleKey))
        {
            ToggleSettings();
        }
    }

    public void ToggleSettings()
    {
        _isOpen = !_isOpen;
        
        if (settingsPanel != null) 
            settingsPanel.SetActive(_isOpen);
        
        // Handle cursor state for the Admin
        Cursor.lockState = _isOpen ? CursorLockMode.None : CursorLockMode.Locked;
        Cursor.visible = _isOpen;
    }

    public void OnSnapshotClick()
    {
        // Triggers the CSV export in the Resource Monitor (Canvas)
        if (monitor != null) monitor.TakeSnapshot();
    }

    public void ExitApplication()
    {
        Application.Quit();
    }
}