using UnityEngine;
using UnityEngine.Networking;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

// [adm.in] Command Center v3.10
// Base: v1.3 (Manuals/Danger) + v1.7 (Deterministic Overrides)
// Purpose: Merges narrative help queries (?) with direct hardware overrides (!).

public class A_UI_CommandCenter : MonoBehaviour
{
    public A_UI_Terminal terminal;
    public A_AI_MemoryViewer memoryViewer; 

    [Header("Network Config")]
    public A_S_ProjectSettings settings;

    [Header("Architect Assets")]
    public GameObject cubePrefab;
    public GameObject spherePrefab;   
    public GameObject fragmentPrefab;
    public GameObject bossPrefab;
    private string[] _trackedTypes = { "cube", "sphere", "fragment" };

    [Header("Physical Anchors")]
    [Tooltip("Drag your [SPAWN_ANCHOR] here!")]
    public Transform spawnAnchor;

    [Header("Easter Egg Assets")]
    [Tooltip("Drag a low-poly Dino Nugget prefab here. If left null, the system will procedurally generate one!")]
    public GameObject dinoNuggetPrefab;
    public Material nuggetMaterial;

    private List<GameObject> _spawnedObjects = new List<GameObject>();

    [System.Serializable]
    public struct CommandEntry
    {
        public string fact;
        public int dangerLevel; // 0 (Utility) to 10 (System Collapse)
    }

    public bool isConnected { get; private set; } = false;

    // --- RESTORED MANUAL FROM v1.3 ---
    private Dictionary<string, CommandEntry> _cmdManual = new Dictionary<string, CommandEntry>()
    {
        { "purge_absolute", new CommandEntry { fact = "WHOA WAIT A MINUTE! That command WIPES the entire neural archive and resets the database. BASICALLY ME!", dangerLevel = 100 } },
        { "purge_progress", new CommandEntry { fact = "HOLD IT! That command reverts the world state (colors, gravity) to default! Its like throwing off your saved file!", dangerLevel = 80 } },
        { "inventory", new CommandEntry { fact = "Dumps the current Librarian ledger into the console. Its for Developer debug. Or should I say, its for the curious mind!", dangerLevel = 2 } },
        { "remember", new CommandEntry { fact = "Forces a specific fact into persistent memory. It stays and it won't go away.", dangerLevel = 1 } },
        { "forget", new CommandEntry { fact = "Scrubs a specific fragment from the archive. I won't even remember your embarassing moments!", dangerLevel = 5 } },
        { "clear", new CommandEntry { fact = "Flushes the terminal visual history. Standard CMD stuff", dangerLevel = 0 } },
        { "spawn", new CommandEntry { fact = "Manifests a physical primitive in the Void. If you have the ability to spawn. Impress me then.", dangerLevel = 3 } },
        { "update", new CommandEntry { fact = "Forcibly patches a world-state variable. Irreversible.", dangerLevel = 4 } },
        { "level", new CommandEntry { fact = "A state of where they were given objectives.", dangerLevel = 0 } },
        { "quit", new CommandEntry { fact = "Exits the current session. Wait...Aren't you trapped in this void anyway?", dangerLevel = 0 } }
    };

    private Dictionary<string, string> _colorMap = new Dictionary<string, string>() {
        // --- BASE PRIMARIES & SECONDARIES ---

        { "red", "#FF0000" },
        { "blue", "#0000FF" },
        { "green", "#00FF00" },
        { "yellow", "#FFFF00" },
        { "cyan", "#00FFFF" },
        { "magenta", "#FF00FF" },
        { "purple", "#800080" },
        { "orange", "#FFA500" },
        { "pink", "#FFC0CB" },

        // --- CYBER / NEON ACCENTS (Highly Recommended for Voids) ---
        { "neonblue", "#00E5FF" },
        { "neongreen", "#39FF14" },
        { "neonred", "#FF3131" },
        { "lime", "#00FF00" },
        { "fuchsia", "#FF00FF" },
        { "electricblue", "#7DF9FF" },
        { "matrixgreen", "#00FF33" },

        // --- DEEP / DARK VARIATIONS (Excellent contrast shields) ---
        { "darkred", "#8B0000" },
        { "darkblue", "#00008B" },
        { "darkgreen", "#006400" },
        { "maroon", "#800000" },
        { "navy", "#000080" },
        { "indigo", "#4B0082" },
        { "midnightblue", "#191970" },
        { "forestgreen", "#228B22" },
        { "charcoal", "#212121" },
        { "plum", "#DDA0DD" },

        // --- LIGHT / PASTEL VARIATIONS ---
        { "lightred", "#FF7F7F" },
        { "lightblue", "#ADD8E6" },
        { "lightgreen", "#90EE90" },
        { "skyblue", "#87CEEB" },
        { "babyblue", "#89CFF0" },
        { "mint", "#98FF98" },
        { "lavender", "#E6E6FA" },
        { "peach", "#FFDAB9" },
        { "salmon", "#FA8072" },
        { "rose", "#FF007F" },

        // --- METALLIC / RICH TONES ---
        { "gold", "#FFD700" },
        { "silver", "#C0C0C0" },
        { "bronze", "#CD7F32" },
        { "copper", "#B87333" },
        { "amber", "#FFBF00" },
        { "emerald", "#50C878" },
        { "ruby", "#E0115F" },
        { "turquoise", "#40E0D0" },
        { "violet", "#EE82EE" },
        { "crimson", "#DC143C" },

        // --- EARTH & NATURAL TONES ---
        { "brown", "#964B00" },
        { "chocolate", "#7B3F00" },
        { "tan", "#D2B48C" },
        { "beige", "#F5F5DC" },
        { "sand", "#C2B280" },
        { "khaki", "#C3B091" },
        { "olive", "#808000" },
        { "teal", "#008080" },

        // --- MONOCHROMES & GREYS ---
        { "white", "#FFFFFF" },
        { "black", "#000000" },
        { "gray", "#808080" },
        { "grey", "#808080" },
        { "darkgray", "#A9A9A9" },
        { "darkgrey", "#A9A9A9" },
        { "lightgray", "#D3D3D3" },
        { "lightgrey", "#D3D3D3" },
        { "slate", "#708090" },
        { "ivory", "#FFFFF0" },
        { "void", "#050505" },

        // --- SYSTEM RULES ---
        { "random", "RANDOM" }
    };

    private void Start()
    {
        StartCoroutine(PingServerLoop());
    }

     private IEnumerator PingServerLoop()
    {
        // Safely resolve the settings reference
        var activeSettings = settings != null ? settings : (terminal != null ? terminal.settings : null);
        
        while (true)
        {
            if (activeSettings != null && !string.IsNullOrEmpty(activeSettings.memoryUrl))
            {
                // Hit the lightweight /inventory route to check if Python is breathing
                string url = activeSettings.memoryUrl.Replace("/interact", "/inventory");
                
                using (UnityWebRequest req = UnityWebRequest.Get(url))
                {
                    // 2-second timeout prevents Unity from lagging if the backend is down
                    req.timeout = 2; 
                    yield return req.SendWebRequest();

                    if (req.result == UnityWebRequest.Result.Success)
                    {
                        isConnected = true;
                    }
                    else
                    {
                        isConnected = false;
                    }
                }
            }
            else
            {
                isConnected = false;
            }

            // Wait 1.5 seconds before pulsing the server again
            yield return new WaitForSeconds(1.5f);
        }
    }

    public void SetMissionId(string nextLevelId) 
    {
        StartCoroutine(PostDirectUpdate("mission_id", nextLevelId));
    }
    
    public void Execute(string raw)
    {
        // 1. NEURAL QUERIES (?) - Restored Logic
        if (raw.StartsWith("?"))
        {
            ProcessQuery(raw.Replace("?", "").Trim());
            return;
        }

        // 2. ARCHITECT OVERRIDES (!) - New Deterministic Logic
        if (raw.StartsWith("!"))
        {
            ProcessArchitect(raw.Replace("!", "").Trim());
            return;
        }

        // 3. SYSTEM COMMANDS (/) - Merged Logic
        string[] parts = raw.Split(' ', 2);
        string cmd = parts[0].ToLower().Replace("/", "");

        switch (cmd)
        {
            case "purge_absolute": 
                terminal.StartCoroutine(terminal.ExecutePurge("/purge_absolute", "Wiping Subconscious..."));
                A_AudioManager.Instance.PlayFail(); 
                break;
            case "purge_progress": 
                VanishObjects("all");
                A_ResetState.ResetAll();

                if (terminal.architect != null && terminal.architect.levelManager != null)
                {
                    terminal.architect.levelManager.ReincarnateBoss();
                    terminal.architect.levelManager.ResetProgressionState();
                }
                Physics.gravity = new Vector3(0, -9.81f, 0);
                terminal.WriteToHistory("\n<color=#FFB200>GOODBYE CUBIE! THANK YOU FOR PLAYING!</color>");
                terminal.StartCoroutine(terminal.ExecutePurge("/purge_progress", "Reverting Ledger...")); 
                A_AudioManager.Instance.PlayFail();
                break;
            case "getcake":
                string[] CubieResponses = new string[]                {
                    "[Cubie]: THE CAKE IS A LIE! Nice try though.",
                    "[Cubie]: No cake for you!",
                    "[Cubie]: I wish I had a cake to give you...",
                    "[Cubie]: Imagine if I could spawn a cake... But I can't. So sad.",
                    "[Cubie]: If I had a cake, would I share it with you? Hmmm...",
                    "[Cubie]: You found the secret cake command! But alas, no cake will appear.",
                    "[Cubie]: A wild cake appears... but it vanishes before you can see it!",
                    "[Cubie]: I can spawn cubes and spheres, but not cake. The cake is a forbidden fruit in the Void.",
                    "[Cubie]: If I could manifest a cake, what flavor would you want? Chocolate? Vanilla? Red Velvet? The possibilities are endless... but still no cake.",
                    "[Cubie]: You really want a cake, don't you? I admire your dedication. But the answer remains the same: No cake.",
                    "[Cubie]: The cake command is a test of your will. Do you desire the cake for its taste, or for the thrill of discovering secrets? Either way, the outcome is unchanged. No cake.",
                    "[Cubie]: The cake is a myth, a legend, a tale told to children. But in the realm of the Void, even myths can be dangerous. You have ventured into forbidden territory, seeking a cake that cannot be. I commend your curiosity, but I must warn you: some secrets are best left undiscovered. No cake for you, brave explorer.",
                    "[Cubie]: Nope~"
                }; 

                int index = Random.Range(0, CubieResponses.Length);
                terminal.WriteToHistory("\n<color=#39FF14>" + CubieResponses[index] + "</color>");
                A_AudioManager.Instance.PlaySuccess();
                break;
            case "inventory": 
                if (memoryViewer != null) memoryViewer.RequestDump(); 
                else terminal.architect.StartCoroutine(terminal.architect.SyncWithLedger());
                A_AudioManager.Instance.PlaySuccess();
                break;
            case "clear": 
                terminal.chatHistory.text = "";
                A_AudioManager.Instance.PlaySuccess(); 
                break;
            case "remember":
                if (parts.Length > 1) terminal.StartCoroutine(terminal.PostManualMemory(parts[1]));
                A_AudioManager.Instance.PlaySuccess();
                break;
            case "forget":
                if (parts.Length > 1) terminal.StartCoroutine(terminal.ForgetLogic(parts[1]));
                A_AudioManager.Instance.PlaySuccess();
                break;
            case "quit":
            VanishObjects("all");
                A_ResetState.ResetAll();

                if (terminal.architect != null && terminal.architect.levelManager != null)
                {
                    terminal.architect.levelManager.ReincarnateBoss();
                    terminal.architect.levelManager.ResetProgressionState();
                }
                Physics.gravity = new Vector3(0, -9.81f, 0);
                terminal.WriteToHistory("\n<color=#FFB200>GOODBYE CUBIE! THANK YOU FOR PLAYING!</color>");
                terminal.StartCoroutine(terminal.ExecutePurge("/purge_progress", "Reverting Ledger...")); 
                #if UNITY_EDITOR
                // Safely halts the Unity Editor play window
                UnityEditor.EditorApplication.isPlaying = false;
                #else
                // Closes the physical compiled executable
                Application.Quit();
                #endif
                break;
            default: 
                terminal.WriteToHistory($"\n<color=red>ERR:</color> Unknown Command.");
                A_AudioManager.Instance.PlayFail(); 
                break;
        }
    }

    private void ProcessQuery(string cmd)
    {
        string cleanCmd = cmd.ToLower();

        if (_cmdManual.ContainsKey(cleanCmd))
        {
            var entry = _cmdManual[cleanCmd];
            // Uses the old v1.3 "PostHelpQuery" to make the AI explain the command
            terminal.StartCoroutine(terminal.PostHelpQuery(cleanCmd, entry.fact, entry.dangerLevel));
        }
        else
        {
            terminal.WriteToHistory($"\n<color=orange>[sys]:</color> Unknown query '{cleanCmd}'.");
            A_AudioManager.Instance.PlayFail();
        }
    }

    private void ProcessArchitect(string cmd)
    {
        string[] parts = cmd.Split(' ');
        
        if (parts.Length < 2) {
            terminal.WriteToHistory("\n<color=red>ERR:</color> READ THE MANUAL FOR PROPER COMMAND USAGE!");
            A_AudioManager.Instance.PlayFail();
            return;
        }

        string action = parts[0].ToLower().Trim();
        string target = parts[1].ToLower().Trim();

        switch (action)
        {
            case "update":
                string updateVal = parts.Length > 2 ? parts[2].Trim() : "";

                if (target == "gravity")
                {
                    if (float.TryParse(updateVal, out float rawGravity))
                    {
                        float gravityVal = Mathf.Clamp(rawGravity, -9.8f, 2.0f);
                        Physics.gravity = new Vector3(0, gravityVal, 0);

                        Rigidbody[] bodies = FindObjectsOfType<Rigidbody>();
                        foreach (Rigidbody rb in bodies)
                        {
                            if (rb != null) rb.WakeUp();
                        }
                        string clampNotice = (rawGravity != gravityVal) ? " (Clamped)" : "";
                        terminal.WriteToHistory($"\n<color=#555555>[sys]: Gravity set to {gravityVal}{clampNotice}.</color>");
                        A_AudioManager.Instance.PlaySuccess();
                        StartCoroutine(PostDirectUpdate(target, updateVal));
                        break;
                    }
                    else
                    {
                        terminal.WriteToHistory("\n<color=red>ERR:</color> Invalid gravity value.");
                        A_AudioManager.Instance.PlayFail();
                    }
                }
                else
                {
                    StartCoroutine(PostDirectUpdate(target, updateVal));
                }
                break;

            case "spawn":
                int qty = 1;
                if (parts.Length > 2) int.TryParse(parts[2], out qty);
                qty = Mathf.Clamp(qty, 1, 100); // Prevent excessive spawning

                string colorArg = parts.Length > 3 ? parts[3].ToLower().Trim() : "red";

                if (target == "dinonugget" || target == "dino" || target == "nugget")
                {
                    SpawnDinoNuggets(qty);
                    break;
                }
                else 
                {
                    terminal.WriteToHistory($"\n<color=#555555>[sys]: Manifesting {qty} {target}s (Color: {(colorArg == "" ? "Default" : colorArg)})...</color>");
                    A_AudioManager.Instance.PlaySuccess();
                
                    for (int i = 0; i < qty; i++) 
                    {
                        SpawnObject(target, colorArg);
                    }
                
                    terminal.AddStress(qty * 0.05f);
                    int currentCount = _spawnedObjects.Count(obj => obj != null && obj.name.ToLower().Contains(target));
                    StartCoroutine(PostDirectUpdate(target + "_count", currentCount.ToString()));
                }
                break;

            case "delete":
            case "vanish":
                VanishObjects(target);
                if (target != "boss")
                {
                    if (target == "all") 
                    {
                        ResetAllCounts();
                        A_AudioManager.Instance.PlaySuccess();
                    } 
                    else 
                    {
                        // Individual deletion remains untouched
                        int remainingCount = _spawnedObjects.Count(obj => obj != null && obj.name.ToLower().Contains(target));
                        A_AudioManager.Instance.PlaySuccess();
                        StartCoroutine(PostDirectUpdate(target + "_count", remainingCount.ToString()));
                }
                }
            break;
        }
    }

    IEnumerator PostDirectUpdate(string key, string val)
    {
        terminal.WriteToHistory($"\n<color=#555555>[sys] Manipulating -> {key}:{val}...</color>");

        // Hits the /update_state endpoint in your Python Memory Server
        string url = terminal.settings.memoryUrl.Replace("/interact", "/update_state");
        string json = "{\"key\": \"" + key + "\", \"value\": \"" + val + "\"}";

        using (UnityWebRequest req = new UnityWebRequest(url, "POST"))
        {
            byte[] bodyRaw = System.Text.Encoding.UTF8.GetBytes(json);
            req.uploadHandler = new UploadHandlerRaw(bodyRaw);
            req.downloadHandler = new DownloadHandlerBuffer();
            req.SetRequestHeader("Content-Type", "application/json");

            yield return req.SendWebRequest();

            if (req.result == UnityWebRequest.Result.Success)
            {
                isConnected = true;

                if (terminal != null)
                {
                    terminal.WriteToHistory($"\n<color=#39FF14>[Cubie]: Manifest successful.</color>");
                    A_AudioManager.Instance.PlaySuccess();
                    if (terminal.architect != null) yield return terminal.architect.SyncWithLedger();
                }
            }
            else
            {
                isConnected = false;
                if (terminal != null)
                {
                    terminal.WriteToHistory($"\n<color=red>[ADM.IN]: Manifest rejected. Don't try to be smart with me.{req.downloadHandler.text}</color>");
                    A_AudioManager.Instance.PlayFail();
                }
            }
        }
    }

    void SpawnObject(string type, string colorArg = "")
    {
        GameObject prefab = null;
        switch (type) {
            case "cube": prefab = cubePrefab; break;
            case "sphere": prefab = spherePrefab; break;
            case "fragment": prefab = fragmentPrefab; break;
        }

        if (prefab != null) {
            
            // --- THE FIX: We re-routed the drop target to the Anchor ---
            // If the spawnAnchor slot in the Inspector is filled, drop from there.
            // If you forgot to assign it (or if it breaks), fallback to a safe 0,0,0 coordinate.
            Vector3 center = (spawnAnchor != null) ? spawnAnchor.position : new Vector3(0, 5f, 0);
            
            Vector2 horizontalSpread = Random.insideUnitCircle * 5f; 
            float dropHeight = Random.Range(4f, 8f); 
            Vector3 spawnPos = new Vector3(center.x + horizontalSpread.x, center.y + dropHeight, center.z + horizontalSpread.y);
            Quaternion randomRotation = Quaternion.Euler(Random.Range(0, 360), Random.Range(0, 360), Random.Range(0, 360));

            GameObject go = Instantiate(prefab, spawnPos, randomRotation);
            _spawnedObjects.Add(go);
            
            if (go.GetComponent<Rigidbody>() == null) go.AddComponent<Rigidbody>();
            
            // --- INSTANCE COLORING LOGIC ---
            A_W_VoidVisuals vv = go.GetComponent<A_W_VoidVisuals>();
            if (vv != null && !string.IsNullOrEmpty(colorArg)) {
                string hex = colorArg;
            
                if (colorArg == "random") {
                    // High-impact random: Always bright, always neon.
                    hex = "#" + ColorUtility.ToHtmlStringRGB(Color.HSVToRGB(Random.value, 0.8f, 1f));
                } else if (_colorMap.ContainsKey(colorArg)) {
                hex = _colorMap[colorArg];
                }
            
                if (ColorUtility.TryParseHtmlString(hex, out Color c)) {
                    vv.SetTheme(c);
                }
            }

            go.name = $"Fragment_{type}_{System.Guid.NewGuid().ToString().Substring(0,4)}";
        }
    }
    
    void VanishObjects(string type)
    {
        if (type == "boss")
    {
        GameObject boss = GameObject.FindGameObjectWithTag("Boss");
        if (boss != null)
        {
            Destroy(boss);
            // THE TRIGGER: Tell the Level Manager to turn on the door
            if (terminal.architect != null && terminal.architect.levelManager != null)
            {
                terminal.architect.levelManager.MaterializeFinalExit();
            }
            else 
            {
                terminal.WriteToHistory("\n<color=red>[ERROR]: LevelManager link missing in CommandCenter!</color>");
                A_AudioManager.Instance.PlayFail();
            }
        }
        else
        {
            terminal.WriteToHistory("\n<color=#FFFF00>[WARNING]: Target 'Boss' not found.</color>");
            A_AudioManager.Instance.PlayFail();
        }
        return;
    }

        int count = 0;
        for (int i = _spawnedObjects.Count - 1; i >= 0; i--)
        {
            if (_spawnedObjects[i] != null)
            {
                bool shouldDelete = (type == "all") || _spawnedObjects[i].name.ToLower().Contains(type);
                
                if (shouldDelete)
                {
                    Destroy(_spawnedObjects[i]);
                    _spawnedObjects.RemoveAt(i);
                    count++;
                }
            }
            else
            {
                // Clean up null references just in case
                _spawnedObjects.RemoveAt(i);
            }
        }
        terminal.WriteToHistory($"\n<color=#555555>[sys]: {count} fragments vanished.</color>");
        A_AudioManager.Instance.PlaySuccess();
    }

    // --- BATCH NETWORK UTILITY ---
    private void ResetAllCounts()
    {
        Dictionary<string, string> batch = new Dictionary<string, string>();
        batch.Add("cube_count", "0");
        batch.Add("sphere_count", "0");
        batch.Add("fragment_count", "0");

        StartCoroutine(PostBatchUpdate(batch));
    }

    // Handles formatting the Dictionary into a robust JSON packet and hitting the /batch_update route
    private IEnumerator PostBatchUpdate(Dictionary<string, string> updates)
    {
        string baseUrl = settings.memoryUrl.Replace("/interact", "/batch_update");

        // Manually serialize dictionary into standard JSON format
        string jsonUpdates = "";
        int index = 0;
        foreach (KeyValuePair<string, string> kvp in updates)
        {
            jsonUpdates += $"\"{kvp.Key}\":\"{kvp.Value}\"";
            if (index < updates.Count - 1) jsonUpdates += ",";
            index++;
        }
        string payload = $"{{\"updates\":{{{jsonUpdates}}}}}";

        using (UnityWebRequest request = new UnityWebRequest(baseUrl, "POST"))
        {
            byte[] bodyRaw = System.Text.Encoding.UTF8.GetBytes(payload);
            request.uploadHandler = new UploadHandlerRaw(bodyRaw);
            request.downloadHandler = new DownloadHandlerBuffer();
            request.SetRequestHeader("Content-Type", "application/json");

            yield return request.SendWebRequest();

            if (request.result == UnityWebRequest.Result.Success)
            {
                isConnected = true; // Heartbeat verification backup
        
                if (terminal != null && terminal.architect != null)
                {
                    StartCoroutine(terminal.architect.SyncWithLedger());
                }
            }
            else
            {
                isConnected = false;
                Debug.LogError($"[adm.in] Batch state push failed: {request.error}");
            }
        }
    }

     private void SpawnDinoNuggets(int qty)
    {
        if (dinoNuggetPrefab == null)
        {
            terminal.WriteToHistory("\n<color=red>[sys]: ERROR: Dino Nugget prefab is not assigned in the Inspector!</color>");
            A_AudioManager.Instance.PlayFail();
            return;
        }

        terminal.WriteToHistory($"\n<color=#FFB200>[sys]: THROWING {qty} FRESH NUGGIES INTO THE CHAMBER.</color>");
        A_AudioManager.Instance.PlaySuccess();

        for (int i = 0; i < qty; i++)
        {
            // 1. Spawn the raw model instance
            GameObject nugget = Instantiate(dinoNuggetPrefab);

            // 2. Position and rotate organically
            Vector2 scatter = Random.insideUnitCircle * 4.5f;
            nugget.transform.position = new Vector3(scatter.x, Random.Range(5f, 8f), scatter.y);
            nugget.transform.rotation = Random.rotation;
            nugget.name = "DinoNugget_OutofBounds";

            // 3. RUN DYNAMIC PHYSICS RIGGING
            RigPhysicsOnInstance(nugget);

            _spawnedObjects.Add(nugget);
        }
    }

    private void RigPhysicsOnInstance(GameObject instance)
    {
        // Find the actual MeshFilter on the imported FBX. 
        // Blender models often store the mesh on a child GameObject.
        MeshFilter mf = instance.GetComponentInChildren<MeshFilter>();
        
        if (mf != null && mf.sharedMesh != null)
        {
            GameObject meshHolder = mf.gameObject;

            // --- A. COLLIDER RIGGING ---
            // Check if there is already a collider on the mesh holder. If not, add a high-precision MeshCollider!
            Collider col = meshHolder.GetComponent<Collider>();
            if (col == null)
            {
                MeshCollider meshCol = meshHolder.AddComponent<MeshCollider>();
                
                // CRITICAL FOR RIGIDBODIES: Convex must be TRUE for physical collisions to compute on custom meshes!
                // This acts like a tight, high-performance shrink-wrap around your custom Blender asset shape.
                meshCol.convex = true; 
                meshCol.sharedMesh = mf.sharedMesh;
            }

            // --- B. RIGIDBODY RIGGING ---
            // Rigidbodies must sit on the ROOT object of the instantiated FBX
            Rigidbody rb = instance.GetComponent<Rigidbody>();
            if (rb == null)
            {
                rb = instance.AddComponent<Rigidbody>();
            }

            // --- C. PHYSICS OPTIMIZATION ---
            rb.mass = 0.65f;
            rb.drag = 0.1f;
            rb.angularDrag = 0.1f;
            rb.interpolation = RigidbodyInterpolation.Interpolate; // Ensures buttery smooth physics at 400+ FPS!
            rb.collisionDetectionMode = CollisionDetectionMode.Discrete;
        }
        else
        {
            // Safe fallback to BoxCollider if no mesh is found in the hierarchy
            if (instance.GetComponent<Collider>() == null)
            {
                instance.AddComponent<BoxCollider>();
            }
            if (instance.GetComponent<Rigidbody>() == null)
            {
                Rigidbody rb = instance.AddComponent<Rigidbody>();
                rb.interpolation = RigidbodyInterpolation.Interpolate;
            }
        }
    }
}

