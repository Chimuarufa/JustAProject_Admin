using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Networking;
using UnityEngine.EventSystems; // Required for clicking UI interaction hooks
using System.Collections;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Text;
using System;
using TMPro;

// [adm.in] Terminal UI v14.6 (Sovereign Focus & Click Handshake Edition)
// Prefix: A_UI (User Interface / Interaction Hub)
// Purpose: Handles kinetic typing, automatic input refocusing, and neural stress accumulation.
// Fix: Frees hardware mouse cursor on open and converts the entire panel into a reactive click-focus zone.
// Hardware Target: GTX 1060 (Stress-Aware) | Storage: 1.1TB Persistence Link.

[RequireComponent(typeof(A_UI_CommandCenter))]
[RequireComponent(typeof(A_AI_Architect))]
public class A_UI_Terminal : MonoBehaviour, IPointerClickHandler
{
    [Header("UI Hierarchy Bindings")]
    public GameObject chatContainer;
    public TMP_InputField inputField;
    public TMP_Text chatHistory;
    public TMP_Text ghostTextTMP;
    public ScrollRect scrollRect;

    [Header("Neural Infrastructure")]
    public A_UI_CommandCenter commandCenter;
    public A_AI_Architect architect;
    public A_S_ProjectSettings settings;
    public A_UI_ResourceMonitor monitor; 
    public A_W_VoidVisuals npcVisuals;    
    public A_LevelManager levelManager;
    public A_PlayerController playerController;

    [Header("Visual Feedback Tokens")]
    public float baseTypeSpeed = 3.0f;
    public string standardHex = "#00FFFF"; // Cyan
    public string cautionHex = "#FFCC00";  // Gold
    public string architectHex = "#39FF14"; // Architect Green
    public string directiveHex = "#555555"; // System Grey
    public string panicHex = "#FF0000";    // Alert Red

    [Header("Neural Stress & Lockout")]
    [Range(0, 100)] public float neuralStress = 0f;
    public float stressDecayRate = 1.25f; 
    public float lockoutDuration = 35f;
    private bool _isLocked = false;

    [Header("Panic & System Trauma")]
    public Color panicTextColor = new Color(1f, 0.1f, 0.1f, 1f); 
    public float jitterIntensity = 75f; 
    public bool shakeCameraOnPanic = true;
    public string[] panicStrings = { 
        "KERNEL_SEGFAULT", "VRAM_OVERFLOW", "STATEDATA_CORRUPT", 
        "MEM_LEAK_DETECTION", "0xDEADBEEF", "NULL_PTR_DEREF", 
        "SOVEREIGN_BYPASS", "CHROMA_DESYNC", "BUFFER_INVALID", "GOODBYE CUBIE! I LOVE YOU!" 
    };

    private System.Collections.Generic.List<string> _cmdHistory = new System.Collections.Generic.List<string>();
    private int _historyIndex = 0;

    // --- INTERNAL STATE ---
    private bool _isTypewriting = false;
    private bool _isChatOpen = false;
    private Vector2 _originalAnchoredPos;
    private RectTransform _containerRect;
    private Color _originalTextColor;
    private Camera _mainCam;
    private float _sessionStartTime;

    void Awake()
    {
        _sessionStartTime = Time.realtimeSinceStartup;
        _mainCam = Camera.main;
        
        if (chatContainer != null) {
            _containerRect = chatContainer.GetComponent<RectTransform>();
            if (_containerRect != null) _originalAnchoredPos = _containerRect.anchoredPosition;
        }
        
        if (chatHistory != null) _originalTextColor = chatHistory.color;
        
        // Auto-Link Logic
        if (commandCenter == null) commandCenter = GetComponent<A_UI_CommandCenter>();
        if (architect == null) architect = GetComponent<A_AI_Architect>();
        if (monitor == null) monitor = FindObjectOfType<A_UI_ResourceMonitor>();

        // ALWAYS keep the cursor completely free, unlocked, and visible from start!
        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;

        SyncSovereignUI(false);

        if (inputField != null)
        {
            inputField.onValueChanged.AddListener(delegate { A_AudioManager.Instance.PlayKeystroke(); });
        }
    }

    void Update()
    {
        // Deterministic Stress Decay
        if (!_isLocked && neuralStress > 0) 
            neuralStress = Mathf.Max(0, neuralStress - (stressDecayRate * Time.deltaTime));

        if (_isLocked) return; 

        // Global Input Listeners
        if (Input.GetKeyDown(KeyCode.Return) && !_isTypewriting) 
        {
            if (!_isChatOpen)
            {
                OpenChat();
                playerController.IsInputLocked = true;
            }
            else
            {
                // If the user has typed text, submit it and immediately refocus!
                if (inputField != null && !string.IsNullOrEmpty(inputField.text))
                {
                    SubmitChat();
                
                    // Keep the flow going: snap focus right back to the text box
                    inputField.ActivateInputField();
                    inputField.Select();
                }
                else
                {
                    // If they pressed Enter on an empty box, close the chat
                    CloseChat();
                    playerController.IsInputLocked = false;
                }
            }
        }

        if (_isChatOpen && _cmdHistory.Count > 0 && inputField != null && inputField.isFocused)
        {
            if (Input.GetKeyDown(KeyCode.UpArrow))
            {
                _historyIndex = Mathf.Max(0, _historyIndex - 1);
                inputField.text = _cmdHistory[_historyIndex];
                StartCoroutine(MoveCaretToEnd());
            }
            else if (Input.GetKeyDown(KeyCode.DownArrow))
            {
                _historyIndex = Mathf.Min(_cmdHistory.Count, _historyIndex + 1);
                if (_historyIndex == _cmdHistory.Count)
                    inputField.text = "";
                else
                    inputField.text = _cmdHistory[_historyIndex];
                
                StartCoroutine(MoveCaretToEnd());
            }
        }

    }

    private IEnumerator MoveCaretToEnd()
    {
        yield return new WaitForEndOfFrame();
        if (inputField != null)
        {
            inputField.caretPosition = inputField.text.Length;
            inputField.ForceLabelUpdate();
        }
    }

    public bool IsLocked() => _isLocked;

    public void SyncSovereignUI(bool isOpen)
    {
        if (_isLocked) return;
        _isChatOpen = isOpen;
        
        if (chatContainer != null) chatContainer.SetActive(isOpen);
        
        if (isOpen)
        {
            if (inputField != null)
            {
                inputField.ActivateInputField(); 
                inputField.Select(); 
            }
        }
        else
        {
            if (inputField != null)
            {
                inputField.DeactivateInputField();
            }
        }

        // Overrides any other script's lock state to keep the mouse completely unrestricted
        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;
    }

    public void OnPointerClick(PointerEventData eventData)
    {
        // If the admin clicks anywhere on the physical terminal UI background, 
        // instantly force-refocus typing back to the input box so you don't have to squint-click!
        if (inputField != null && _isChatOpen && !_isLocked)
        {
            inputField.ActivateInputField();
            inputField.Select();
        }
    }

    public void OpenChat() => SyncSovereignUI(true);

    public void CloseChat() { if (inputField != null) inputField.text = ""; SyncSovereignUI(false); }

    public void InitiateAwakening()
    {
        if (_isChatOpen || _isTypewriting) return;
        OpenChat();
        WriteToHistory("\n<color=#555555>[sys]: Interaction detected. Establishing neural handshake...</color>");
    }

    void SubmitChat()
    {
        if (inputField == null || string.IsNullOrEmpty(inputField.text)) { 
            CloseChat(); 
            return; 
        }

        string txt = inputField.text;
        SubmitChat(txt);
        inputField.text = "";
    }

    public void SubmitChat(string txt)
    {
        if (string.IsNullOrEmpty(txt)) return;

        if (_cmdHistory.Count == 0 || _cmdHistory[_cmdHistory.Count - 1] != txt)
        {
            _cmdHistory.Add(txt);
        }
        _historyIndex = _cmdHistory.Count;

        // --- LEVEL 3 CIPHER INTERCEPT ---
        if (txt == "4927" && levelManager.currentMissionId == "level_3")
        {
            WriteToHistory($"\n<color=#00ffcc>[SYSTEM_NODE]: Password '4927' accepted. Local security bypassed.</color>");
            
            if (levelManager.hiddenDoorL3 != null) 
            {
                levelManager.hiddenDoorL3.SetActive(true);
            }
            
            return;
        }
        // --- THE MONOLITH ROUTER ---
        if (txt.StartsWith("/") || txt.StartsWith("!")) {
            string color = txt.StartsWith("!") ? architectHex : directiveHex;
            string prefix = txt.StartsWith("!") ? "!" : "/";
            WriteToHistory($"\n<color={cautionHex}>Hacking:{prefix}</color>{txt.Substring(1)}");
            commandCenter.Execute(txt);
        } 
        else if (txt.StartsWith("?")) {
            WriteToHistory($"\n<color={cautionHex}>ASKED:?</color>{txt.Substring(1)}");
            commandCenter.Execute(txt);
        }
        else {
            WriteToHistory($"\n<color=#FFCC00>USER:</color>{txt}");
            StartCoroutine(PostToAI(txt));
        }
    }

    public void WriteToHistory(string text) 
    {
        if (chatHistory != null) { 
            chatHistory.text += text; 
            ScrollToBottom(); 
        }
    }

    // --- NARRATIVE HELP QUERIES ---
    public IEnumerator PostHelpQuery(string cmd, string fact, int dangerLevel = 0)
    {
        AddStress(dangerLevel * 2.5f);
        string targetHex = (dangerLevel >= 7) ? cautionHex : standardHex;
        
        string prompt = $"Admin is querying the technical manual for '{cmd}'. " +
                        $"Fact: {fact}. Explain this briefly but snarkily. " +
                        $"Danger Level is {dangerLevel}/10.";

        yield return StartCoroutine(PostToAI(prompt, targetHex));
    }

    // --- SYSTEM OPERATIONS & TRAUMA ---
    public IEnumerator ExecutePurge(string endpoint, string msg) 
    {
        yield return StartCoroutine(TriggerKernelPanic(msg));
        
        string targetUrl = settings.memoryUrl.Replace("/interact", endpoint);
        
        // THE FIX: Use standard, clean UnityWebRequest.PostWwwForm directly
        using (UnityWebRequest req = UnityWebRequest.PostWwwForm(targetUrl, ""))
        {
            req.timeout = 15;
            yield return req.SendWebRequest();

            if (req.result == UnityWebRequest.Result.Success) 
            {
                if (architect != null) yield return architect.SyncWithLedger();
                WriteToHistory("\n<color=#00ffcc>[sys]: World Ledger successfully flushed.</color>");
            } 
            else 
            {
                WriteToHistory($"\n<color=orange>[sys]: Flush Failed: {req.error}</color>");
            }
        }
        _isTypewriting = false;
    }

    public IEnumerator TriggerKernelPanic(string msg) 
    {
        _isTypewriting = true;
        if (chatHistory != null) chatHistory.color = panicTextColor;
        WriteToHistory($"\n<color=white>[CRITICAL_FAILURE]: {msg}</color>");
        
        Vector3 camOriginalPos = _mainCam != null ? _mainCam.transform.position : Vector3.zero;
        float t = 0;
        float duration = 3.0f;
        float spamTimer = 0f;

        while (t < duration) {
            float strength = (1.0f - (t / duration)); 
            
            // Jitter UI
            if (_containerRect != null) 
                _containerRect.anchoredPosition = _originalAnchoredPos + UnityEngine.Random.insideUnitCircle * jitterIntensity * strength;
            
            // Shake Camera
            if (shakeCameraOnPanic && _mainCam != null) 
                _mainCam.transform.position = camOriginalPos + (Vector3)(UnityEngine.Random.insideUnitCircle * 0.35f * strength);
            
            // --- RED WORD SPAM LOOP ---
            spamTimer += Time.deltaTime;
            if (spamTimer >= 0.045f) {
                string err = panicStrings[UnityEngine.Random.Range(0, panicStrings.Length)];
                WriteToHistory($"\n<color=red>ERR_{err} // {UnityEngine.Random.Range(1000, 9999)}</color>");
                spamTimer = 0;
            }

            t += Time.deltaTime;
            yield return null;
        }

        // Reset Visuals
        if (_containerRect != null) _containerRect.anchoredPosition = _originalAnchoredPos;
        if (shakeCameraOnPanic && _mainCam != null) _mainCam.transform.position = camOriginalPos;
        
        if (chatHistory != null) { 
            chatHistory.text = "<color=red>[adm.in.sys]: REBOOTING NEURAL KERNEL...</color>\n"; 
            chatHistory.color = _originalTextColor; 
        }
        
        _isTypewriting = false;
        ScrollToBottom();
    }

    public void AddStress(float amount) 
    {
        neuralStress = Mathf.Min(100, neuralStress + amount);
        if (neuralStress >= 100 && !_isLocked) StartCoroutine(InitiateLockout());
    }

    private IEnumerator InitiateLockout() 
    {
        _isLocked = true;
        CloseChat();
        yield return StartCoroutine(TriggerKernelPanic("NEURAL_COLLAPSE // ADM_OVERLOAD"));
        WriteToHistory($"\n<color=red>[CRITICAL]: ADMIN PRIVILEGES REVOKED FOR {lockoutDuration}s.</color>");
        yield return new WaitForSeconds(lockoutDuration);
        WriteToHistory("\n<color=#00ffcc>[sys]: Kernel Stabilized. Access Restored.</color>");
        _isLocked = false;
        neuralStress = 25f; // Lingering stress
    }

    // --- NEURAL HANDSHAKE ---
    public IEnumerator PostToAI(string prompt, string moodHex = null) 
    {
        if (ghostTextTMP != null) ghostTextTMP.text = "<color=#00ffcc>Always wait for adm.in to respond...</color>";
        
        // Librarian JSON Payload
        string json = "{\"prompt\": \"" + prompt.Replace("\"", "\\\"") + "\", \"model\": \"" + settings.modelName + "\"}";
        
        using (UnityWebRequest req = new UnityWebRequest(settings.memoryUrl, "POST")) 
        {
            byte[] body = Encoding.UTF8.GetBytes(json);
            req.uploadHandler = new UploadHandlerRaw(body);
            req.downloadHandler = new DownloadHandlerBuffer();
            req.SetRequestHeader("Content-Type", "application/json");
            
            yield return req.SendWebRequest();
            
            if (req.result == UnityWebRequest.Result.Success) {
                string raw = ExtractContent(req.downloadHandler.text);
                
                // --- MULTI-LAYER SCRUBBER ---
                raw = Regex.Replace(raw, @"(?s)adm\.in:.*?\n", "");
                raw = Regex.Replace(raw, @"(?s)STATE:.*?\n", "");
                raw = Regex.Replace(raw, @"(?s)DIRECTIVE:.*?\n", "");
                raw = Regex.Replace(raw, @"(?s)ROLE:.*?\n", "");
                raw = Regex.Replace(raw, @"(?s)MEMORIES:.*?\n", "");

                // Mood Interpretation
                string derivedHex = moodHex ?? standardHex;
                Match moodMatch = Regex.Match(raw, @"\[MOOD:(.*?)\]", RegexOptions.IgnoreCase);
                if (moodMatch.Success) {
                    string m = moodMatch.Groups[1].Value.ToUpper();
                    if (m == "ANGRY") derivedHex = "#FF4444";
                    else if (m == "FRIENDLY") derivedHex = "#39FF14";
                    else if (m == "CAUTION") derivedHex = cautionHex;
                    raw = raw.Replace(moodMatch.Value, "").Trim();
                }

                SyncNPCMood(derivedHex);
                
                // If the Architect is linked, let it analyze the text for spawning tags
                if (architect != null && !prompt.Contains("querying")) architect.Execute(raw);
                
                StartCoroutine(NeuralTypewriter(raw, derivedHex));
            } else {
                WriteToHistory($"\n<color=orange>[sys]: Neural link timed out. Check Port 8000.</color>");
            }
        }
    }

    public void SyncNPCMood(string hex) 
    {
        if (npcVisuals != null && ColorUtility.TryParseHtmlString(hex, out Color c)) {
            npcVisuals.SetTheme(c);
            if (monitor != null) monitor.moodHex = hex;
        }
    }

    IEnumerator NeuralTypewriter(string fullText, string hex) 
    {
        _isTypewriting = true;
        WriteToHistory($"\n<color={hex}>adm.in:</color> ");
        
        foreach (char c in fullText) { 
            chatHistory.text += c; 
            
            // --- NEURAL NOISE STUTTER ---
            if (neuralStress > 45f && UnityEngine.Random.value < (neuralStress/100f) * 0.12f) {
                chatHistory.text += (UnityEngine.Random.value > 0.5f ? "_" : ".");
                yield return new WaitForSeconds(baseTypeSpeed * 5f);
            }
            
            yield return new WaitForSeconds(baseTypeSpeed); 
        }
        
        _isTypewriting = false;
        ScrollToBottom();
        if (ghostTextTMP != null) ghostTextTMP.text = "";
    }

    // --- MANUAL PERSISTENCE METHODS ---
    public IEnumerator PostManualMemory(string content) {
        string url = settings.memoryUrl.Replace("/interact", "/add_memory");
        string guid = System.Guid.NewGuid().ToString().Substring(0, 8);
        string json = "{\"id\": \"MANUAL_" + guid + "\", \"text\": \"" + content.Replace("\"", "\\\"") + "\"}";
        
        WriteToHistory("\n<color=#555555>[sys]: Writing manual law to disk...</color>");
        
        using (UnityWebRequest req = new UnityWebRequest(url, "POST")) {
            byte[] b = Encoding.UTF8.GetBytes(json);
            req.uploadHandler = new UploadHandlerRaw(b);
            req.downloadHandler = new DownloadHandlerBuffer();
            req.SetRequestHeader("Content-Type", "application/json");
            yield return req.SendWebRequest();
            if (req.result == UnityWebRequest.Result.Success) 
                WriteToHistory("\n<color=#00ffcc>[sys]: Archive updated.</color>");
        }
    }

    public IEnumerator ForgetLogic(string q) {
        string url = settings.memoryUrl.Replace("/interact", "/forget");
        string json = "{\"prompt\": \"" + q.Replace("\"", "\\\"") + "\"}";
        
        WriteToHistory("\n<color=#555555>[sys]: Purging neural fragment...</color>");
        
        using (UnityWebRequest req = new UnityWebRequest(url, "POST")) {
            byte[] b = Encoding.UTF8.GetBytes(json);
            req.uploadHandler = new UploadHandlerRaw(b);
            req.downloadHandler = new DownloadHandlerBuffer();
            req.SetRequestHeader("Content-Type", "application/json");
            yield return req.SendWebRequest();
            if (req.result == UnityWebRequest.Result.Success) 
                WriteToHistory("\n<color=#00ffcc>[sys]: Fragment scrubbed.</color>");
        }
    }

    string ExtractContent(string json) 
    {
        try {
            int start = json.IndexOf("\"content\":\"") + 11;
            int end = json.LastIndexOf("\"}");
            if (start < 11 || end < 0) return "[STREAM_CORRUPTED]";
            return Regex.Unescape(json.Substring(start, end - start));
        } catch { 
            return "[DESYNC_ERROR]"; 
        }
    }

    void ScrollToBottom() 
    { 
        if (scrollRect != null) { 
            Canvas.ForceUpdateCanvases(); 
            scrollRect.verticalNormalizedPosition = 0; 
        } 
    }
}