using UnityEngine;
using System.Collections;
using System.Text;
using TMPro;
using UnityEngine.UI;

// [adm.in] UI Dashboard v1.7 (Active Network Probe Edition)
// Prefix: A_UI (User Interface)
// Purpose: Implements an active network scanner that probes all bridge scripts to prevent gateway deadlocks.

public class A_UI_Dashboard : MonoBehaviour
{
    [Header("Core System Links")]
    public A_UI_Terminal terminal;
    public A_LevelManager levelManager;
    public A_S_ProjectSettings settings;

    // --- FALLBACK PROBE REFERENCES ---
    // The script will dynamically inspect both types at runtime to find the active connection!
    private A_UI_CommandCenter _uiCommandCenter;
    private A_AI_Bridge _aiBridge;

    [Header("UI Panels")]
    public GameObject bootMenuPanel;       // The "Main Menu" panel
    public GameObject operationalHUDPanel; // Contains Terminal, Mission UI, and Guide UI
    
    [Header("Top-Middle Mission UI")]
    public TMP_Text missionTitleText;
    public TMP_Text missionDescText;
    
    [Header("Bottom-Right Guide UI")]
    public TMP_Text guideHeaderText;
    public TMP_Text guideContentText;

    [Header("Boot Terminal Visuals")]
    public TMP_Text bootTerminalText;      // Dedicated main BIOS terminal screen
    public Button establishLinkButton;

    private TMP_Text _buttonText;          // Handles only the button text (No reference hijacking)
    private bool _isBooted = false;

    public bool IsBooted => _isBooted;

    void Awake()
    {
        // Enforce clean starting state for the application lifecycle
        if (bootMenuPanel != null) bootMenuPanel.SetActive(true);
        if (operationalHUDPanel != null) operationalHUDPanel.SetActive(false);
        
        if (establishLinkButton != null) 
        {
            establishLinkButton.gameObject.SetActive(false);
            
            // Protects bootTerminalText from being overwritten
            _buttonText = establishLinkButton.GetComponentInChildren<TMP_Text>();
        }
    }

    void Start()
    {
        if (bootMenuPanel != null && bootMenuPanel.activeSelf)
        {
            StartCoroutine(RunBootSequence());
        }
    }

    // --- MAIN MENU: SOVEREIGN BIOS BOOT SEQUENCE ---
    private IEnumerator RunBootSequence()
    {
        StringBuilder sb = new StringBuilder();
        
        if (bootTerminalText != null)
        {
            bootTerminalText.text = "";
        }

        string[] bootLines = new string[]
        {
            "<size=50><b><color=#00FFCC>[PROJECT: ADM.IN]  VERSION 1.7</color></b></size=20>",
            "Autonomous Directorive Memory & Intelligent Network\n\n",
            "-----------------------------------------------------------------",
            "[adm.in] BIOS v4.95 - INITIALIZING SOVEREIGN NODE...",
            "CPU: " + SystemInfo.processorType,
            "GPU: " + SystemInfo.graphicsDeviceName + " (6GB VRAM TARGET)",
            "RAM: " + (SystemInfo.systemMemorySize / 1024) + " GB DETECTED",
            "-----------------------------------------------------------------",
            "DETECTING LOCAL STORAGE... OK.",
            "CONNECTING TO CHROMA_DB AT PORT 8000... OK.",
            "WAKING NEURAL INFRASTRUCTURE (OLLAMA)... OK.",
            "MODEL SEATED: " + (settings != null ? settings.modelName : "dolphin-mistral:7b"),
            "-----------------------------------------------------------------",
            "WARNING: SYSTEM OPERATING IN COGNITIVE INSTABILITY ZONE.",
            "PROCEEDING WITHOUT COGNITIVE SAFETY NET.",
            "INITIALIZING INTERACTION SHELL...",
            "<color=#00FFCC>// PRESS TAB TO ENSURE THE MODEL IS SET TO \"LINKED\"</color>",
            "<color=#00FFCC>// you might need to wait a little...my GPU and RAM is acting weird. If status link stayed <color=#FF0000>OFFLINE</color> for more than 2 minutes, restart the program.</color>",
            "<color=#FFEA00>[sys]: You are a hacker who can manifest and manipulate reality at will. Your job is to explore the possibilities and finish the challenge given by ADM.IN, the autonomous directorive memory & intelligent network. basically...a room observer...</color>",
            "\n\n<color=#AAFF00>Tip: Always wait until response is given if you having a normal conversationbefore sending a new query. Spamming inputs may cause the system to become more unstable.</color>"
        };

        foreach (string line in bootLines)
        {
            sb.AppendLine(line);
            if (bootTerminalText != null)
            {
                bootTerminalText.text = sb.ToString();
            }
            yield return new WaitForSeconds(Random.Range(0.03f, 0.1f));
        }

        yield return new WaitForSeconds(0.5f);
        sb.AppendLine("\n>>> WAITING FOR BACKEND TO RESPOND...");
        if (bootTerminalText != null)
        {
            bootTerminalText.text = sb.ToString();
        }

        // Display the button so the user can watch the loading animation
        if (establishLinkButton != null)
        {
            establishLinkButton.gameObject.SetActive(true);
            establishLinkButton.onClick.AddListener(EstablishAdminLink);
        }

        // --- THE ACTIVE NETWORK PROBE LOOP ---
        // Loops until we find ANY valid, active script reporting a connected state
        while (!CheckIfAnyNetworkIsConnected())
        {
            if (establishLinkButton != null)
            {
                establishLinkButton.interactable = false; // Disable button click safely
            }

            if (_buttonText != null)
            {
                // Dynamic dots loading loop
                string dots = new string('.', (int)(Time.realtimeSinceStartup % 4));
                _buttonText.text = $"<color=#FFB200>[WAITING FOR BACKEND{dots}]</color>";
            }
            yield return null; // Check again on the next frame
        }

        // --- THE UNLOCK ---
        // Exited loop! A connected bridge was found in the scene.
        if (establishLinkButton != null)
        {
            establishLinkButton.interactable = true; // Unlock clicking!
            if (_buttonText != null)
            {
                _buttonText.text = "<color=#00FFCC>> ENTER VOID <</color>";
            }
        }
    }

    // --- ACTIVE NETWORK PROBE ROUTINE ---
    // Automatically checks all possible network controllers in the active scene hierarchy
    private bool CheckIfAnyNetworkIsConnected()
    {
        // 1. Probe the active AI Bridge (where the successful handshake printed!)
        if (_aiBridge == null) _aiBridge = FindObjectOfType<A_AI_Bridge>();
        if (_aiBridge != null && _aiBridge.isConnected) 
        {
            return true;
        }

        // 2. Fallback to Command Center if active
        if (_uiCommandCenter == null) _uiCommandCenter = FindObjectOfType<A_UI_CommandCenter>();
        if (_uiCommandCenter != null && _uiCommandCenter.isConnected) 
        {
            return true;
        }

        return false;
    }

    public void EstablishAdminLink()
    {
        if (_isBooted) return;
        _isBooted = true;

        // Transition from Main Menu to Operational UI Panels
        if (bootMenuPanel != null) bootMenuPanel.SetActive(false);
        if (operationalHUDPanel != null) operationalHUDPanel.SetActive(true);

        if (terminal != null)
        {
            terminal.WriteToHistory("\n<color=#00FFCC>[sys]: Press TAB to ensure the status is set to \"LINKED\". If not, restart program.</color>");
        }
    }

    public void RefreshInterface(string currentLevelId, string missionTitle, string missionDesc, string guideContent)
    {
        if (missionTitleText != null) missionTitleText.text = missionTitle.ToUpper();
        if (missionDescText != null) missionDescText.text = missionDesc;

        if (guideHeaderText != null) guideHeaderText.text = $"<color=#00FFCC>// ADMIN_MANUAL_v1.2 //</color>";
        if (guideContentText != null) guideContentText.text = guideContent;
    }
}