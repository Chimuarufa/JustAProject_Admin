using UnityEngine;
using UnityEngine.Profiling;
using TMPro;
using System.Text;
using System;
using System.IO;
using System.Collections.Generic;
using System.Runtime.InteropServices;

// [adm.in] Resource Monitor v2.8 (The Emotive Diagnostic)
// Prefix: A_UI (User Interface)
// Base: v2.7 + Neural Mood Tracking
// Purpose: Displays the AI's current "Emotional State" alongside hardware telemetry.

public class A_UI_ResourceMonitor : MonoBehaviour
{
    [Header("UI Hierarchy Bindings")]
    public GameObject hudPanel;
    public TMP_Text telemetryText;
    
    [Header("Neural & Data Connections")]
    public A_S_ProjectSettings settings;
    public A_AI_Bridge bridge; 
    public A_UI_Terminal terminal;

    [Header("Telemetry Settings")]
    public float updateInterval = 0.35f; 
    public string logFileName = "adm_in_siege_data.csv";

    // Live Mood tracking for the HUD
    [HideInInspector] public string currentMood = "STABLE";
    [HideInInspector] public string moodHex = "#00FFFF";

    // --- WIN32 KERNEL ACCESS: MEMORY PRECISION ---
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
    private class MEMORYSTATUSEX
    {
        public uint dwLength;
        public uint dwMemoryLoad;
        public ulong ullTotalPhys;
        public ulong ullAvailPhys;
        public ulong ullTotalPageFile;
        public ulong ullAvailPageFile;
        public ulong ullTotalVirtual;
        public ulong ullAvailVirtual;
        public ulong ullAvailExtendedVirtual;
        public MEMORYSTATUSEX() { this.dwLength = (uint)Marshal.SizeOf(typeof(MEMORYSTATUSEX)); }
    }

    [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool GlobalMemoryStatusEx([In, Out] MEMORYSTATUSEX lpBuffer);

    private float _accumulatedFps = 0;
    private int _frames = 0;
    private float _timeLeft;
    private float _startTime;

    private string _cpuName;
    private string _gpuName;
    private ulong _totalPhysRam;
    private string _logPath;
    private bool _isInitialized = false;

    void Start()
    {
        _startTime = Time.realtimeSinceStartup;
        _timeLeft = updateInterval;
        
        _cpuName = SystemInfo.processorType;
        _gpuName = SystemInfo.graphicsDeviceName;
        _logPath = Path.Combine(Application.dataPath, logFileName);
        
        MEMORYSTATUSEX memStatus = new MEMORYSTATUSEX();
        if (GlobalMemoryStatusEx(memStatus)) 
            _totalPhysRam = memStatus.ullTotalPhys / 1024 / 1024;

        if (hudPanel != null) hudPanel.SetActive(true); 

        try {
            if (!File.Exists(_logPath))
                File.WriteAllText(_logPath, "Timestamp,Model,Mood,Stress,FPS,ms,VRAM_Est,RAM_Used\n");
            _isInitialized = true;
        } catch (Exception e) {
            Debug.LogError($"[adm.in]: Logging Disabled: {e.Message}");
        }
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Tab) && hudPanel != null)
            hudPanel.SetActive(!hudPanel.activeSelf);

        _accumulatedFps += Time.unscaledDeltaTime;
        _frames++;

        _timeLeft -= Time.unscaledDeltaTime;
        if (_timeLeft <= 0.0)
        {
            UpdateDisplay();
            _timeLeft = updateInterval;
        }
    }

    void UpdateDisplay()
    {
        if (telemetryText == null) return;

        float fps = _frames / _accumulatedFps;
        float ms = (_accumulatedFps / _frames) * 1000f;
        _accumulatedFps = 0;
        _frames = 0;

        StringBuilder sb = new StringBuilder();
        
        // --- 1. SYSTEM KERNEL & MOOD ---
        string statusText = "OFFLINE";
        string statusColor = "#ff4444";
        if (bridge != null && bridge.isConnected) { statusText = "LINKED"; statusColor = "#00ffcc"; }

        TimeSpan t = TimeSpan.FromSeconds(Time.realtimeSinceStartup - _startTime);

        sb.AppendLine("<color=#ffcc00>[ADM_IN_KERNEL_v2.8]</color>");
        sb.AppendLine($"STATUS: <color={statusColor}>{statusText}</color> | CLK: {DateTime.Now:HH:mm:ss}");
        
        // NEW: Display the Manifested Mood in the HUD
        sb.AppendLine($"MOOD: <color={moodHex}>{currentMood}</color> | SESS: {t.Hours:D2}:{t.Minutes:D2}:{t.Seconds:D2}");
        
        // --- 2. NEURAL STRESS ---
        if (terminal != null)
        {
            float stress = terminal.neuralStress;
            string stressColor = stress > 80 ? "#ff4444" : (stress > 40 ? "#ffcc00" : "#00ffcc");
            sb.AppendLine($"STRESS: <color={stressColor}>[{GetProgressBar(stress)}] {stress:F1}%</color>");
            if (terminal.IsLocked()) sb.AppendLine("<color=red>!! KERNEL_LOCKOUT_ACTIVE !!</color>");
        }

        sb.AppendLine("--------------------");

        // --- 3. HARDWARE IDENTIFICATION ---
        sb.AppendLine($"CPU: <color=#aaaaaa>{_cpuName}</color>");
        sb.AppendLine($"GPU: <color=#aaaaaa>{_gpuName}</color>");

        // --- 4. PERFORMANCE ANALYSIS ---
        string msColor = ms > 33 ? "#ff4444" : (ms > 18 ? "#ffcc00" : "#ffffff");
        sb.AppendLine($"PERF: <color=#ffffff>{fps:F0} FPS</color> (<color={msColor}>{ms:F2}ms</color>)");

        long ramUsed = 0;
        MEMORYSTATUSEX memStatus = new MEMORYSTATUSEX();
        if (GlobalMemoryStatusEx(memStatus))
            ramUsed = (long)(_totalPhysRam - (memStatus.ullAvailPhys / 1024 / 1024));
        else ramUsed = System.GC.GetTotalMemory(false) / 1024 / 1024;

        sb.AppendLine($"RAM: {ramUsed}MB / {_totalPhysRam}MB");
        
        long vramUsed = GetGlobalVramUsed();
        int vramLimit = SystemInfo.graphicsMemorySize;
        string vramColor = vramUsed > (vramLimit * 0.9f) ? "#ff4444" : "#ffcc00";
        sb.AppendLine($"VRAM: <color={vramColor}>{vramUsed}MB</color> / {vramLimit}MB");
        
        // --- 5. NEURAL PARAMETERS ---
        if (settings != null)
        {
            sb.AppendLine("--------------------");
            sb.AppendLine($"BRAIN: <color=#ffcc00>{settings.modelName}</color>");
            string seed = (bridge != null && bridge.isConnected) ? UnityEngine.Random.Range(100000, 999999).ToString("X") : "0xIDLE";
            sb.AppendLine($"TEMP: {settings.temperature:F1} | SEED: {seed}");
        }

        telemetryText.text = sb.ToString();
    }

    string GetProgressBar(float val)
    {
        int bars = (int)(val / 10f);
        return new string('I', bars).PadRight(10, '.');
    }

    public void TakeSnapshot() 
    {
        if (!_isInitialized || settings == null) return;

        float stress = terminal != null ? terminal.neuralStress : 0;
        float fps = _frames > 0 ? _frames / _accumulatedFps : 0;
        float ms = _frames > 0 ? (_accumulatedFps / _frames) * 1000f : 0;
        
        long ramUsed = System.GC.GetTotalMemory(false) / 1024 / 1024;
        
        string line = $"{DateTime.Now:HH:mm:ss},{settings.modelName},{currentMood},{stress:F1},{fps:F1},{ms:F2},{GetGlobalVramUsed()},{ramUsed}";
        
        try {
            File.AppendAllText(_logPath, line + "\n");
            Debug.Log($"<color=#00ffcc>[adm.in]:</color> Telemetry Snapshot Saved to {_logPath}");
            if (terminal != null) 
                terminal.WriteToHistory("\n<color=#555555>[sys]: Local telemetry snapshot synced to drive.</color>");
        } catch (Exception e) {
            Debug.LogError($"[adm.in]: Snapshot Write Failure: {e.Message}");
        }
    }

    long GetGlobalVramUsed()
    {
        long unityReserved = Profiler.GetTotalReservedMemoryLong() / 1024 / 1024;
        long osTax = 720; 
        long modelTax = 0;
        if (settings != null)
        {
            string m = settings.modelName.ToLower();
            if (m.Contains("7b") || m.Contains("8b")) modelTax = 4850;
            else if (m.Contains("4b") || m.Contains("3b")) modelTax = 2650;
            else if (m.Contains("1.5b") || m.Contains("2b")) modelTax = 1250;
        }
        return unityReserved + osTax + modelTax;
    }
}